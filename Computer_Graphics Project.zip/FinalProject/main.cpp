#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include<cmath>
#include <math.h>
#include<iostream>
using namespace std;
int currentScenerio = 0;

//scenario 1

bool active=false, night = false,lighthouse=false;
int ship=0,window=0, blx=0,bly=0,c1=0,c2=1300,car=0,car1=0,light=0,step=2;

//Scenario 2
const int NUM_POINTS = 50;
float timeElapsed = 0.0f;
float _ang_tri = 0.0;//train
bool moving = false;
float carPosition = 0.0;//car
float bx = 0.0; //car1
float _rain = 0.0;
float cloud1PosX = 0.0f; //  first cloud
float cloud2PosX = -150.0f; // second cloud
const float cloudSpeed = 1.0f; // Speed
bool isNight = false;
bool rainday = false;

//scenario 3
#define PI 3.14159265358979323846
float carPositionX = 0.0f;
float car2=0.0f;
bool Night=false;
bool carRunning = false;
float cloud1PositionX = 0.0f;
float cloud2PositionX = -300.0f;
float cloud3PositionX = -600.0f;
const float sceneWidth = 1500.0f;
float bladeAngle = 0.0; // Initial blade rotation angle

//scenario 4
float cloudX = 0;
float sunY = 800; // Sun's vertical position
float moonY = 800;    // Moon position (simulates slow movement)
bool isDay = true; // Toggle for day and night mode
bool moonGoingDown = true;
float birdX = -100, birdFlap = 0;  // Bird movement variables
float sx= 370;
bool timerRunning = false;

//scenario 2

void drawSun(float x, float y) {
    glPushMatrix();
    glColor3f(1.0f, 1.0f, 0.0f);
    glTranslatef(x, y, 0.0);
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * 3.1416 / 180;
        float xPos = 50 * cos(theta);
        float yPos = 50 * sin(theta);
        glVertex2f(xPos, yPos);
    }
    glEnd();
    glPopMatrix();
}

//Moon Function

void drawMoon(float x, float y) {
    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glTranslatef(x, y, 0.0);
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * 3.1416 / 180; //deg to rad
        float xPos = 50 * cos(theta);
        float yPos = 50 * sin(theta);
        glVertex2f(xPos, yPos);
    }
    glEnd();
    glPopMatrix();
}

// circle function for cloud

void drawCircle(float centerX, float centerY, float radius) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centerX, centerY); // Center of the circle
    for (int i = 0; i <= 360; i++) {
        float angle = i * 3.1416 / 180.0f; // deg to rad
        float x = centerX + cos(angle) * radius;
        float y = centerY + sin(angle) * radius;
        glVertex2f(x, y);
    }
    glEnd();
}


void drawCloud(float x, float y) {
    if (isNight) return;

    if (rainday) {
        glColor3f(0.2f, 0.2f, 0.2f); // Dark gray for rain clouds
    } else {
        glColor3f(1.0f, 1.0f, 1.0f);
    }

    drawCircle(x, y, 30);
    drawCircle(x + 35, y, 30);
    drawCircle(x - 35, y, 30);
    drawCircle(x + 15, y + 25, 25);
    drawCircle(x - 15, y + 25, 25);
}

//car function

void circle(GLfloat rx, GLfloat ry, GLfloat cx, GLfloat cy)
{
    glBegin(GL_POLYGON);
    glVertex2f(cx, cy);
    for (int i = 0; i <= 360; i++)
    {
        float angle = i * 3.1416 / 180;
        float x = rx * cos(angle);
        float y = ry * sin(angle);
        glVertex2f((x + cx), (y + cy));
    }
    glEnd();
}

//Lampost Function

void drawLampPost(float x, float y) {
    // Lamp post piller
    glBegin(GL_QUADS);
    glColor3f(0.5f, 0.5f, 0.5f);
    glVertex2f(x, y);
    glVertex2f(x + 10, y);
    glVertex2f(x + 10, y + 100);
    glVertex2f(x, y + 100);
    glEnd();

        // Lamp light
    if (isNight) {
        glBegin(GL_POLYGON);
        glColor3f(1.0f, 1.0f, 0.0f);
        for (int i = 0; i < 360; i += 10) {
            float angle = i * 3.14159f / 180.0f;
            glVertex2f(x + 15 * cos(angle) + 5, y + 100 + 15 * sin(angle)); // light
        }
        glEnd();
    }
    else if (rainday) {
        glBegin(GL_POLYGON);
        glColor3f(1.0f, 1.0f, 0.0f);
        for (int i = 0; i < 360; i += 10) {
            float angle = i * 3.14159f / 180.0f;
            glVertex2f(x + 15 * cos(angle) + 5, y + 100 + 15 * sin(angle)); // light
        }
        glEnd();
    }

    else {
        glBegin(GL_POLYGON);
        glColor3f(1.0f, 1.0f, 1.0f);
        for (int i = 0; i < 360; i += 10) {
            float angle = i * 3.14159f / 180.0f;
            glVertex2f(x + 15 * cos(angle) + 5, y + 100 + 15 * sin(angle)); // light
        }
        glEnd();
    }

}

//scenario 3
void updateCarPosition(int value) {
    if (carRunning) {
        carPositionX += 5.0f; // Move the car continuously

        // Reset position if car moves out of scene
        if (carPositionX > sceneWidth) {
            carPositionX = -200.0f; // Reset to starting position
        }

        glutPostRedisplay();
        glutTimerFunc(16, updateCarPosition, 0);
    }
}
// Function to draw a circle (used for clouds)
void drawCircle2(float centerX, float centerY, float radius, int segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centerX, centerY); // Center of the circle
    for (int i = 0; i <= segments; i++) {
        float theta = 2.0f * PI * i / segments;
        float x = centerX + radius * cos(theta);
        float y = centerY + radius * sin(theta);
        glVertex2f(x, y);
    }
    glEnd();
}
// draw a cloud at a given position
void drawCloud1(float x, float y)
 {
        if(Night)
 {
   glColor3ub(0,0,0);
 }
 else
    {glColor3ub(255, 255, 255); }// White color for the clouds}
    drawCircle2(x, y, 40.0f, 50);   // Center part
    drawCircle2(x - 30, y, 30.0f, 50); // Left part
    drawCircle2(x + 30, y, 30.0f, 50); // Right part
    drawCircle2(x, y + 20, 25.0f, 50); // Top part
}
void drawCircle0(float centerX, float centerY, float radius, int segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centerX, centerY);
    for (int i = 0; i <= segments; i++) {
        float theta = 2.0f * PI * i / segments;
        float x = centerX + radius * cos(theta);
        float y = centerY + radius * sin(theta);
        glVertex2f(x, y);
    }
    glEnd();
}
void drawCar1() {
    glPushMatrix(); // Save the current transformation matrix

    // Move the car1
    glTranslatef(carPositionX, 0.0f, 0.0f);

    // Draw the car1 body
    glColor3ub(0, 0, 102);
    glBegin(GL_POLYGON);
    glVertex2f(200, 350);
    glVertex2f(400, 350);
    glVertex2f(400, 400);
    glVertex2f(370, 440);
    glVertex2f(230, 440);
    glVertex2f(200, 400);
    glEnd();
    // Draw the windows
       if(Night)
 {
   glColor3ub(255,255,0);
 }
 else

    {glColor3ub(0,0,0);}// Light blue color for windows

    // Window 1 (Left)
    glBegin(GL_QUADS);
    glVertex2f(240, 390);
    glVertex2f(300, 390);
    glVertex2f(300, 435);
    glVertex2f(250, 420);
    glEnd();

    // Window 2 (Right)
    glBegin(GL_QUADS);
    glVertex2f(310, 390);
    glVertex2f(360, 390);
    glVertex2f(360, 415);
    glVertex2f(310, 435);
    glEnd();
    // Draw the wheels
    glColor3ub(0, 0, 0); // Black color for wheels
    drawCircle0(250, 340, 20.0f, 100); // First wheel
    drawCircle0(350, 340, 20.0f, 100); // Second wheel

    glPopMatrix(); // Restore the transformation matrix
}
void drawCircle1(float centerX, float centerY, float radius, int segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centerX, centerY); // Center of the circle
    for (int i = 0; i <= segments; i++) {
        float theta = 2.0f * PI * i / segments;
        float x = centerX + radius * cos(theta);
        float y = centerY + radius * sin(theta);
        glVertex2f(x, y);
    }
    glEnd();
}
void drawCar2() {
    glPushMatrix(); // Save the current transformation matrix

// Move the car
    glTranslatef(car2, 0.0f, 0.0f);

    // Draw the car2 body
    glColor3ub(204, 0, 0); // Yellow car body
    glBegin(GL_POLYGON);
    glVertex2f(1000, 370);
    glVertex2f(1200, 370);
    glVertex2f(1200, 420);
    glVertex2f(1170, 440);
    glVertex2f(1020, 440);
    glVertex2f(1000, 420);
    glEnd();

    // Draw the windows (large size)
        if(Night)
 {
   glColor3ub(255,255,0);
 }
 else

    {glColor3ub(0, 0, 0);} // Light blue color for windows
 // Window 1

    glBegin(GL_QUADS);
    glVertex2f(1020, 420);
    glVertex2f(1040, 420);
    glVertex2f(1040, 435);
    glVertex2f(1020, 425);
    glEnd();
    // Window 2

    glBegin(GL_QUADS);
    glVertex2f(1050, 420);
    glVertex2f(1080, 420);
    glVertex2f(1080, 435);
    glVertex2f(1050, 435);
    glEnd();
    // Window 3

    glBegin(GL_QUADS);
    glVertex2f(1090, 420);
    glVertex2f(1120, 420);
    glVertex2f(1120, 435);
    glVertex2f(1090, 435);
    glEnd();
    // Window 4

    glBegin(GL_QUADS);
    glVertex2f(1130, 420);
    glVertex2f(1155, 420);
    glVertex2f(1155, 435);
    glVertex2f(1130, 435);
    glEnd();

    // Window 5

    glBegin(GL_QUADS);
    glVertex2f(1165, 420);
    glVertex2f(1185, 420);
    glVertex2f(1185, 425);
    glVertex2f(1165, 435);
    glEnd();
    // bus door

    glBegin(GL_QUADS);
    glVertex2f(1160, 370);
    glVertex2f(1190, 370);
    glVertex2f(1190, 410);
    glVertex2f(1160, 410);
    glEnd();
    // Draw the wheels
    glColor3ub(1, 1, 1); // Black color for wheels
    float wheelRadius = 20.0f;
    drawCircle1(1050, 360, wheelRadius, 100); // First wheel
    drawCircle1(1150, 360, wheelRadius, 100); // Second wheel

    glPopMatrix(); // Restore the transformation matrix
}
//wind
void d(float cx, float cy, float r, int num_segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= num_segments; i++) {
        float theta = 2.0f * PI * float(i) / float(num_segments);
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
}
void drawBlade(float cx, float cy, float length, float angle) {
    float rad = angle * PI / 180.0;
    float x1 = cx + length * cos(rad);
    float y1 = cy + length * sin(rad);

    glBegin(GL_TRIANGLES);
    glVertex2f(cx, cy);
    glVertex2f(x1 - 5, y1);
    glVertex2f(x1 + 5, y1);
    glEnd();
}


//scenario 4


void clouds(int value){
    glPushMatrix();
    glPopMatrix();
    sx +=2;
    if(sx>530){
        sx = 370;
    }
    glutTimerFunc(25, clouds, 0);
    glutPostRedisplay();

}
//Cloud
void drawCloud3(float x, float y) {
    glColor3f(0.984f, 0.984f, 0.984f); // White color for clouds
       if (!isDay) glColor3f(0.6f, 0.6f, 0.6f); // Darker at night
    float radius = 40.0f;
    int num_segments = 50;
    glBegin(GL_POLYGON);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float dx = radius * cosf(theta);
        float dy = radius * sinf(theta);
        glVertex2f(dx + x+ cloudX, dy + y);
    }

     glutTimerFunc(25, clouds, 0);
    glutPostRedisplay();
     glPopMatrix();
    glEnd();
}


#define STAR_COUNT 100

struct Star {
    int x, y;
};

Star stars[STAR_COUNT];

void initStars() {
    for (int i = 0; i < STAR_COUNT; i++) {
        stars[i].x = rand() % 1500;
        stars[i].y = 600 + rand() % 500; // Ensuring stars are in the upper part
    }
}

void drawStars() {

    glPointSize(2);
    glColor3f(1.0f, 1.0f, 1.0f); // White stars
    glBegin(GL_POINTS);
    for (int i = 0; i < STAR_COUNT; i++) {
        glVertex2i(stars[i].x, stars[i].y);
    }
    glEnd();
}


///bird
void drawBird(float x, float y) {
    glColor3f(0.0f, 0.0f, 0.0f); // Black color for birds
    glBegin(GL_LINES);
    glVertex2f(x, y);
    glVertex2f(x + 15, y + 10 + birdFlap);  // Wing up
    glVertex2f(x, y);
    glVertex2f(x - 15, y + 10 - birdFlap);  // Wing down
    glEnd();
}




void display() {

    if(currentScenerio==0){
            glClear(GL_COLOR_BUFFER_BIT);
            glLoadIdentity();
            gluOrtho2D(0,1500,0,1000);
            glMatrixMode(GL_MODELVIEW);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
              //------------>First scenario<---------------

            glBegin(GL_QUADS);
            if(night) glColor3f(0.05f, 0.05f, 0.2f);
            else glColor3f(0.678f, 0.847f, 0.902f);  //sky
            glVertex2f(0,0);
            glVertex2f(1500,0);
            glVertex2f(1500,1000);
            glVertex2f(0,1000);
            glEnd();
            if(!night){
                glPushMatrix();
                glTranslatef(850, 900.0, 0.0);//sun
                glBegin(GL_POLYGON);
                glColor3f(1.0f, 1.0f, 0.6f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=40;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
                glPopMatrix();
            }
            else{
                glPushMatrix();
                glTranslatef(850, 900.0, 0.0);
                glBegin(GL_POLYGON);
               glColor3f(1.0f, 1.0f, 0.8f);//moon
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=40;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
                glPopMatrix();
                glPushMatrix();
                glTranslatef(865, 900.0, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.05f, 0.05f, 0.2f);//moon
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=35;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
                glPopMatrix();
            }
            glBegin(GL_POLYGON);//mountains
            glColor3f(0.0f, 0.329f, 0.471f);
            glVertex2f(0,550);
            glVertex2f(0,700);
            glVertex2f(100,760);
            glVertex2f(120,730);
            glVertex2f(180,800);
            glVertex2f(240,700);
            glVertex2f(260,730);
            glVertex2f(300,700);
            glVertex2f(300,550);
            glEnd();

            glBegin(GL_POLYGON);//mountains
            if(night) glColor3f(0.1f, 0.3f, 0.25f);
            else glColor3f(0.2f, 0.6f, 0.5f);
            glVertex2f(150,550);
            glVertex2f(200,650);
            glVertex2f(320,770);
            glVertex2f(380,850);
            glVertex2f(500,650);
            glVertex2f(520,730);
            glVertex2f(600,650);
            glVertex2f(700,550);
            glEnd();
            glBegin(GL_POLYGON);//mountains
            if (night) glColor3f(0.15f, 0.4f, 0.3f);
            else glColor3f(0.3f, 0.75f, 0.6f);
            glVertex2f(220,550);
            glVertex2f(260,600);
            glVertex2f(320,700);
            glVertex2f(400,770);
            glVertex2f(480,650);
            glVertex2f(530,620);
            glVertex2f(590,550);

            glEnd();
            glBegin(GL_QUADS);
            if(night )glColor3f(0.2f, 0.2f, 0.2f);
            else glColor3f(0.94f, 0.87f, 0.73f);//land
            glVertex2f(0, 450);
            glVertex2f(1500, 450);
            glVertex2f(1500, 380);
            glVertex2f(0, 380);
            glEnd();
            glBegin(GL_QUADS);
            if(night)glColor3f(0.2f, 0.1f, 0.1f);
            else glColor3f(0.85f, 0.45f, 0.25f); //stone
            glVertex2f(0, 450);
            glVertex2f(1500, 450);
            glVertex2f(1500, 470);
            glVertex2f(0, 470);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.0f, 0.2f, 0.2f);
            else glColor3f(0.0f, 0.573f, 0.561f);//grass
            glVertex2f(0, 470);
            glVertex2f(1500, 470);
            glVertex2f(1500, 550);
            glVertex2f(0, 550);
            glEnd();

            int bush=0;
            for(int i=0;i<30;i++){
            glBegin(GL_TRIANGLES);
            if(night) glColor3f(0.1f, 0.3f, 0.1f);
            else glColor3f(0.380f, 0.788f, 0.333f); //bush
            glVertex2f(bush+0, 470);
            glVertex2f(bush+50, 470);
            glVertex2f(bush+25, 490);

            glVertex2f(bush+0, 475);
            glVertex2f(bush+50, 475);
            glVertex2f(bush+25, 495);

            glVertex2f(bush+0, 480);
            glVertex2f(bush+50, 480);
            glVertex2f(bush+25, 500);

            glVertex2f(bush+0, 485);
            glVertex2f(bush+50, 485);
            glVertex2f(bush+25, 500);
            glEnd();
            bush+=50;
            }

            glBegin(GL_QUADS);
            if(night) glColor3f(0.3f, 0.3f, 0.3f);
            else glColor3f(0.75f, 0.75f, 0.75f); //road
            glVertex2f(0, 520);
            glVertex2f(1500, 520);
            glVertex2f(1500, 550);
            glVertex2f(0, 550);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.1f, 0.1f, 0.1f);
            else glColor3f(0.3f, 0.3f, 0.3f); //road shadow
            glVertex2f(0, 520);
            glVertex2f(1500, 520);
            glVertex2f(1500, 510);
            glVertex2f(0, 510);
            glEnd();
            int road=0;
            for(int i=0;i<5;i++){
            glBegin(GL_QUADS);
            if(night) glColor3f(0.1f, 0.1f, 0.1f);
            else glColor3f(0.3f, 0.3f, 0.3f); //road shadow
            glVertex2f(road+100, 470);
            glVertex2f(road+130, 470);
            glVertex2f(road+130, 510);
            glVertex2f(road+100, 510);
            glEnd();
            road+=300;
            }

            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.2f, 0.2f);
            else glColor3f(0.6f, 0.6f, 0.6f); //lighthouse
            glVertex2f(1260,650);
            glVertex2f(1340,650);
            glVertex2f(1340,670);
            glVertex2f(1260,670);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f); //lighthouse
            glVertex2f(1270,670);
            glVertex2f(1330,670);
            glVertex2f(1330,750);
            glVertex2f(1270,750);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f); //lighthouse
            glVertex2f(1270,750);
            glVertex2f(1275,750);
            glVertex2f(1275,780);
            glVertex2f(1270,780);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f); //lighthouse
            glVertex2f(1325,750);
            glVertex2f(1330,750);
            glVertex2f(1330,780);
            glVertex2f(1325,780);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.25f, 0.13f, 0.05f);
            else glColor3f(0.55f, 0.27f, 0.07f);  //lighthouse
            glVertex2f(1290,750);
            glVertex2f(1310,750);
            glVertex2f(1310,755);
            glVertex2f(1290,755);
            glEnd();
            glPushMatrix();
                glTranslatef(1300, 762.0, 0.0);//light
                glBegin(GL_POLYGON);
                glColor3f(1.0f, 0.9f, 0.7f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=10;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glBegin(GL_TRIANGLES);
            glColor3f(0.25f, 0.25f, 0.25f); //lighthouse
            glVertex2f(1260,780);
            glVertex2f(1300,820);
            glVertex2f(1340,780);
            glEnd();

            glBegin(GL_POLYGON);
            if(night)glColor3f(0.2f, 0.1f, 0.1f);
            else glColor3f(0.85f, 0.45f, 0.25f); //stone
            glVertex2f(1080,550);
            glVertex2f(1080,570);
            glVertex2f(1250,650);
            glVertex2f(1350,650);
            glVertex2f(1500,570);
            glVertex2f(1500,550);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f); //building
            glVertex2f(620,550);
            glVertex2f(1080,550);
            glVertex2f(1080,680);
            glVertex2f(620,680);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.3f, 0.4f);
            else glColor3f(0.4f, 0.6f, 0.8f);//building window
            glVertex2f(625,550);
            glVertex2f(825,550);
            glVertex2f(825,670);
            glVertex2f(625,670);
            glEnd();
            bly=0;
            glBegin(GL_QUADS);
            for(int j=0;j<3;j++){
                    blx=0;
                for(int i=0;i<5;i++){
                    if(night)glColor3f(1.0f, 0.9f, 0.6f);
                    else glColor3f(0.678f, 0.847f, 0.902f);//body window
                    glVertex2f(blx+630,bly+555);
                    glVertex2f(blx+655,bly+555);
                    glVertex2f(blx+655,bly+570);
                    glVertex2f(blx+630,bly+570);
                    blx = blx+40;
                }bly+=35;
            }
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.3f, 0.4f);
            else glColor3f(0.4f, 0.6f, 0.8f);//building window
            glVertex2f(875,550);
            glVertex2f(1075,550);
            glVertex2f(1075,670);
            glVertex2f(875,670);
            glEnd();
            bly=0;
            glBegin(GL_QUADS);
            for(int j=0;j<3;j++){
                    blx=0;
                for(int i=0;i<5;i++){
                    if(night)glColor3f(1.0f, 0.9f, 0.6f);
                    else glColor3f(0.678f, 0.847f, 0.902f);//body window
                    glVertex2f(blx+880,bly+555);
                    glVertex2f(blx+905,bly+555);
                    glVertex2f(blx+905,bly+570);
                    glVertex2f(blx+880,bly+570);
                    blx = blx+40;
                }bly+=35;
            }
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.15f, 0.15f, 0.15f);
            else glColor3f(0.3f, 0.3f, 0.3f);//building door
            glVertex2f(830,550);
            glVertex2f(870,550);
            glVertex2f(870,610);
            glVertex2f(830,610);
            glEnd();

            int k=0;
            for(int i=0;i<10;i++){

                glBegin(GL_QUADS);
                if(night) glColor3f(0.2f, 0.125f, 0.05f);
                else glColor3f(0.4f, 0.25f, 0.1f);//light
                glVertex2f(k+100,550);
                glVertex2f(k+110,550);
                glVertex2f(k+110,600);
                glVertex2f(k+100,600);
                glEnd();
                glBegin(GL_QUADS);
                if(night) glColor3f(0.2f, 0.125f, 0.05f);
                else glColor3f(0.4f, 0.25f, 0.1f);//light
                glVertex2f(k+97,600);
                glVertex2f(k+113,600);
                glVertex2f(k+113,620);
                glVertex2f(k+97,620);
                glEnd();
                glPushMatrix();
                glTranslatef(k+105, 610.0, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(1.0f, 1.0f, 0.6f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=5;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
                glPopMatrix();
                k+=215;
            }




            glBegin(GL_QUADS);
            if(night) glColor3f(0.0f, 0.25f, 0.35f);
            else glColor3f(0.0f, 0.5f, 0.7f);//water
            glVertex2f(0, 380);
            glVertex2f(1500, 420);
            glVertex2f(1500, 0);
            glVertex2f(0, 0);
            glEnd();

            glBegin(GL_QUADS);
            if(night) glColor3f(0.05f, 0.1f, 0.15f);
            else glColor3f(0.1f, 0.2f, 0.3f);//boat
            glVertex2f(1250, 380);
            glVertex2f(1400, 380);
            glVertex2f(1380, 360);
            glVertex2f(1270, 360);
            glEnd();

            glBegin(GL_QUADS);
            if(night)glColor3f(0.27f, 0.14f, 0.04f);
            else glColor3f(0.54f, 0.27f, 0.07f);
            glVertex2f(1325, 380);
            glVertex2f(1330, 380);
            glVertex2f(1330, 470);
            glVertex2f(1325, 470);
            glEnd();
            glBegin(GL_TRIANGLES);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);
            glVertex2f(1330,470);
            glVertex2f(1330,400);
            glVertex2f(1400,400);
            glEnd();
            glBegin(GL_TRIANGLES);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);
            glVertex2f(1325,470);
            glVertex2f(1325,400);
            glVertex2f(1280,400);
            glEnd();


             // Light blue transparent shine
            glBegin(GL_POLYGON);
            glColor4f(0.7f, 0.9f, 1.0f, 0.4f);
            glVertex2f(ship+130, 75);
            glVertex2f(ship+550, 75);
            glVertex2f(ship+250, 55);
            glVertex2f(ship+130, 75);
            glEnd();



            //speedboat
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.2f, 0.2f);
            else glColor3f(0.3f, 0.3f, 0.3f);
            glVertex2f(950, 300);
            glVertex2f(900, 350);
            glVertex2f(1200, 350);
            glVertex2f(1100, 300);
            glEnd();

            glBegin(GL_QUADS);
            if(night) glColor3f(0.45f, 0.45f, 0.4f);
            else glColor3f(0.9f, 0.9f, 0.8f);
            glVertex2f(950, 350);
            glVertex2f(1050, 350);
            glVertex2f(1050, 370);
            glVertex2f(950, 370);
            glEnd();
            glBegin(GL_QUADS);
            if(night)glColor3f(1.0f, 0.9f, 0.6f);
            else glColor3f(0.4f, 0.6f, 0.8f);
            glVertex2f(960, 350);
            glVertex2f(1040, 350);
            glVertex2f(1040, 365);
            glVertex2f(960, 365);
            glEnd();
            blx=0;

            for(int i=0;i<6;i++){
            glBegin(GL_QUADS);
            if(night)glColor3f(1.0f, 0.9f, 0.6f);
            else glColor3f(0.75f, 0.75f, 0.75f);
            glVertex2f(blx+950, 320);
            glVertex2f(blx+970, 320);
            glVertex2f(blx+970, 340);
            glVertex2f(blx+950, 340);
            blx+=30;
            glEnd();
            }

            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.25f, 0.4f);
            else glColor3f(0.4f, 0.5f, 0.8f);
            glVertex2f(1050, 350);
            glVertex2f(1055, 350);
            glVertex2f(1055, 420);
            glVertex2f(1050, 420);
            glEnd();
            glBegin(GL_TRIANGLES);
            if(night) glColor3f(0.3f, 0.3f, 0.3f);
            else glColor3f(0.75f, 0.75f, 0.75f);
            glVertex2f(1055, 420);
            glVertex2f(1120, 350);
            glVertex2f(1190, 350);
            glEnd();


            //---------->SHIP CODE <------------
            glPushMatrix();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.275f, 0.0f, 0.0f);
            else glColor3f(0.55f, 0.0f, 0.0f);//red
            glVertex2f(ship+150,100);
            glVertex2f(ship+530,100);
            glVertex2f(ship+500,70);
            glVertex2f(ship+170,70);
            glVertex2f(ship+150,80);
            glEnd();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);//white body
            glVertex2f(ship+100,180);
            glVertex2f(ship+100,150);
            glVertex2f(ship+150,100);
            glVertex2f(ship+530,100);
            glVertex2f(ship+610,180);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//body shadow
            glVertex2f(ship+100,180);
            glVertex2f(ship+100,170);
            glVertex2f(ship+600,170);
            glVertex2f(ship+610,180);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.3f, 0.4f);
            else glColor3f(0.4f, 0.6f, 0.8f);//body window
            glVertex2f(ship+150,165);
            glVertex2f(ship+540,165);
            glVertex2f(ship+540,150);
            glVertex2f(ship+150,150);
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<20;i++){
                if(night)glColor3f(1.0f, 0.9f, 0.6f);
                    else glColor3f(0.678f, 0.847f, 0.902f);//body window
                glVertex2f(ship+window+160,165);
                glVertex2f(ship+window+170,165);
                glVertex2f(ship+window+170,150);
                glVertex2f(ship+window+160,150);
                window+=20;
            }
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<40;i++){
                glColor3f(0.1f, 0.1f, 0.1f);//body window
                glVertex2f(ship+window+155,140);
                glVertex2f(ship+window+160,140);
                glVertex2f(ship+window+160,130);
                glVertex2f(ship+window+155,130);
                window+=10;
            }
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);//first layer
            glVertex2f(ship+150,180);
            glVertex2f(ship+540,180);
            glVertex2f(ship+540,200);
            glVertex2f(ship+150,200);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//first layer shadow
            glVertex2f(ship+150,200);
            glVertex2f(ship+540,200);
            glVertex2f(ship+540,205);
            glVertex2f(ship+150,205);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.3f, 0.4f);
            else glColor3f(0.4f, 0.6f, 0.8f);//window
            glVertex2f(ship+150,185);
            glVertex2f(ship+540,185);
            glVertex2f(ship+540,195);
            glVertex2f(ship+150,195);
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<19;i++){
                if(night)glColor3f(1.0f, 0.9f, 0.6f);
                    else glColor3f(0.678f, 0.847f, 0.902f);// window
                glVertex2f(ship+window+160,185);
                glVertex2f(ship+window+170,185);
                glVertex2f(ship+window+170,195);
                glVertex2f(ship+window+160,195);
                window+=20;
            }
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);//second layer
            glVertex2f(ship+150,205);
            glVertex2f(ship+540,205);
            glVertex2f(ship+530,225);
            glVertex2f(ship+160,225);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//second layer shadow
            glVertex2f(ship+160,225);
            glVertex2f(ship+530,225);
            glVertex2f(ship+530,230);
            glVertex2f(ship+160,230);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.3f, 0.4f);
            else glColor3f(0.4f, 0.6f, 0.8f);//window
            glVertex2f(ship+160,210);
            glVertex2f(ship+530,210);
            glVertex2f(ship+530,220);
            glVertex2f(ship+160,220);
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<18;i++){
                if(night)glColor3f(1.0f, 0.9f, 0.6f);
                    else glColor3f(0.678f, 0.847f, 0.902f);// window
                glVertex2f(ship+window+170,210);
                glVertex2f(ship+window+180,210);
                glVertex2f(ship+window+180,220);
                glVertex2f(ship+window+170,220);
                window+=20;
            }
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);//third layer
            glVertex2f(ship+170,230);
            glVertex2f(ship+310,230);
            glVertex2f(ship+300,245);
            glVertex2f(ship+180,245);
            glEnd();
            glBegin(GL_QUADS);
            if(night)glColor3f(1.0f, 0.9f, 0.6f);
            else glColor3f(0.678f, 0.847f, 0.902f);
            glVertex2f(ship+180,232);
            glVertex2f(ship+300,232);
            glVertex2f(ship+293,243);
            glVertex2f(ship+187,243);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);//chimney
            glVertex2f(ship+400,230);
            glVertex2f(ship+450,230);
            glVertex2f(ship+450,280);
            glVertex2f(ship+400,280);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.2f, 0.2f, 0.2f);
            else glColor3f(0.5f, 0.5f, 0.5f);//chimney shadow
            glVertex2f(ship+400,280);
            glVertex2f(ship+450,280);
            glVertex2f(ship+450,285);
            glVertex2f(ship+400,285);
            glEnd();
            glBegin(GL_QUADS);
            if(night) glColor3f(0.4f, 0.4f, 0.5f);
            else glColor3f(0.9f, 0.9f, 0.9f);//design
            glVertex2f(ship+210,245);
            glVertex2f(ship+210,290);
            glVertex2f(ship+250,290);
            glVertex2f(ship+280,245);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//design
            glVertex2f(ship+210,245);
            glVertex2f(ship+210,250);
            glVertex2f(ship+278,250);
            glVertex2f(ship+280,245);
            glEnd();

            glPushMatrix();
                glTranslatef(c1, 925.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+25, 910.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+25, 940.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+50, 910-50.0, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+50, 940.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+75, 925.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
             glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+200, 960.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+225, 945.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+225, 975.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+250, 945.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+250, 975.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c1+275, 960.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c2, 950.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c2+25, 935.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
               if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c2+25, 965.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c2+50, 935.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c2+50, 965.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
            glPushMatrix();
                glTranslatef(c2+75, 950.0-50, 0.0);//clouds
                glBegin(GL_POLYGON);
                if(night) glColor3f(0.4f, 0.4f, 0.5f);
                else glColor3f(0.9f, 0.9f, 0.9f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=20;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();

            //-------->CAR<---------
            glPopMatrix();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.3f, 0.3f, 0.0f);
            else glColor3f(1.0f, 0.8f, 0.0f);
            glVertex2f(car+0,550-15);
            glVertex2f(car+150,550-15);
            glVertex2f(car+150,590-15);
            glVertex2f(car+145,585-15);
            glVertex2f(car+0,580-15);
            glEnd();

            glBegin(GL_POLYGON);
            if(night) glColor3f(0.7f, 1.0f, 0.9f);
            else glColor3f(0.4f, 0.5f, 0.8f);
            glVertex2f(car+0,580-15);
            glVertex2f(car+145,580-15);
            glVertex2f(car+150,585-15);
            glVertex2f(car+150,600-15);
            glVertex2f(car+145,595-15);
            glVertex2f(car+140,600-15);
            glVertex2f(car+0,600-15);
            glEnd();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.3f, 0.3f, 0.0f);
            else glColor3f(1.0f, 0.8f, 0.0f);
            glVertex2f(car+0,600-15);
            glVertex2f(car+140,600-15);
            glVertex2f(car+145,610-15);
            glVertex2f(car+10,610-15);
            glEnd();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.3f, 0.3f, 0.0f);
            else glColor3f(1.0f, 0.8f, 0.0f);
            glVertex2f(car+140,600-15);
            glVertex2f(car+145,595-15);
            glVertex2f(car+150,600-15);
            glVertex2f(car+145,610-15);
            glEnd();
            // car wheel
            glPushMatrix();
                glTranslatef(car+125, 535.0, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.0f, 0.0f, 0.0f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=10;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
             glPushMatrix();
                glTranslatef(car+25, 535.0, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.0f, 0.0f, 0.0f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=10;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();

            glBegin(GL_POLYGON);
            if(night)glColor3f(0.1f, 0.2f, 0.3f);
            else glColor3f(0.2f, 0.4f, 0.5f);//car2
            glVertex2f(car1+1495,535-5);
            glVertex2f(car1+1485,550-5);
            glVertex2f(car1+1400,550-5);
            glVertex2f(car1+1390,535-5);
            glEnd();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.1f, 0.2f, 0.3f);
            else glColor3f(0.2f, 0.4f, 0.5f);
            glVertex2f(car1+1420,550-5);
            glVertex2f(car1+1430,560-5);
            glVertex2f(car1+1465,560-5);
            glVertex2f(car1+1475,550-5);
            glEnd();
             glBegin(GL_POLYGON);
            if(night) glColor3f(0.7f, 1.0f, 0.9f);
            else glColor3f(0.4f, 0.5f, 0.8f);
            glVertex2f(car1+1422,550-5);
            glVertex2f(car1+1432,558-5);
            glVertex2f(car1+1463,558-5);
            glVertex2f(car1+1473,550-5);
            glEnd();
            glPushMatrix();
                glTranslatef(car1+1420, 535.0-5, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.0f, 0.0f, 0.0f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=8;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
             glPushMatrix();
                glTranslatef(car1+1475, 535.0-5, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.0f, 0.0f, 0.0f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=8;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();

            glBegin(GL_POLYGON);
            if(night) glColor3f(0.3f, 0.0f, 0.0f);
            else glColor3f(1.0f, 0.0f, 0.0f);//car3
            glVertex2f(car1+1495+500,535-5);
            glVertex2f(car1+1485+500,550-5);
            glVertex2f(car1+1400+500,550-5);
            glVertex2f(car1+1390+500,535-5);
            glEnd();
            glBegin(GL_POLYGON);
            if(night) glColor3f(0.3f, 0.0f, 0.0f);
            else glColor3f(1.0f, 0.0f, 0.0f);
            glVertex2f(car1+1420+500,550-5);
            glVertex2f(car1+1430+500,560-5);
            glVertex2f(car1+1465+500,560-5);
            glVertex2f(car1+1475+500,550-5);
            glEnd();
             glBegin(GL_POLYGON);
            if(night) glColor3f(0.7f, 1.0f, 0.9f);
            else glColor3f(0.4f, 0.5f, 0.8f);
            glVertex2f(car1+1422+500,550-5);
            glVertex2f(car1+1432+500,558-5);
            glVertex2f(car1+1463+500,558-5);
            glVertex2f(car1+1473+500,550-5);
            glEnd();
            glPushMatrix();
                glTranslatef(car1+1420+500, 535.0-5, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.0f, 0.0f, 0.0f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=8;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();
             glPushMatrix();
                glTranslatef(car1+1475+500, 535.0-5, 0.0);
                glBegin(GL_POLYGON);
                glColor3f(0.0f, 0.0f, 0.0f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=8;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            glPopMatrix();

            //lighthouse light
            if(lighthouse){
                glPopMatrix();
                glBegin(GL_POLYGON);
                glColor4f(1.0f, 0.9f, 0.6f,0.2f);
                glVertex2f(1290,760);
                glVertex2f(1310,760);
                glVertex2f(light+1090,250);
                glVertex2f(light+910,250);
                glEnd();
                glPushMatrix();
                glTranslatef(light+1000, 250, 0.0);
                glBegin(GL_POLYGON);
                glColor4f(1.0f, 0.9f, 0.6f,0.6f);
                for(int j=0;j<360;j++){
                    float pi=3.1416;
                    float A=(j*2*pi)/180;
                    float r=90;
                    float x = r * cos(A);
                    float y = r * sin(A);
                    glVertex2f(x,y);
                }
                glEnd();
            }
    }





    if(currentScenerio==1){
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    gluOrtho2D(0,1500,0,1000);
	glMatrixMode(GL_MODELVIEW);


             ///Sky

        if (isNight && rainday) {
            glColor3f(0.1f, 0.1f, 0.2f);
        } else if (isNight) {
            glColor3f(0.0f, 0.0f, 0.2f);
        } else if (rainday) {
            glColor3f(0.3f, 0.3f, 0.5f);
        } else {
            glColor3f(0.529f, 0.808f, 0.922f);
        }
            glBegin(GL_QUADS);
            glVertex2i(0, 550);
            glVertex2i(1500, 550);
            glVertex2i(1500, 1000);
            glVertex2i(0, 1000);
            glEnd();


            /// SUN OR MOON

        if (isNight && !rainday) {
            drawMoon(1250, 900);
        } else if (!isNight) {
            drawSun(1250, 900);
        }


           ///clouds
           //2 clouds

            drawCloud(cloud1PosX, 950.0f); // Cloud 1
            drawCloud(cloud2PosX, 850.0f); // Cloud 2

             if (rainday) {
                drawCloud(600, 900);
                drawCloud(800, 850);
                drawCloud(1000, 920);
                drawCloud(1250, 900);
            }



            ///Hill

        if (isNight && rainday) {
                glColor3f(0.1f, 0.3f, 0.1f);
            } else if (isNight) {
                glColor3f(0.0f, 0.2f, 0.05f);
            } else if (rainday) {
                glColor3f(0.0f, 0.5f, 0.1f);
            } else {
                glColor3f(0.0f, 0.4f, 0.1f);
            }

            glBegin(GL_POLYGON);
            glVertex2i(-50, 686);
            glVertex2i(250, 850);
            glVertex2i(500, 800);
            glVertex2i(750, 850);
            glVertex2i(1000, 750);
            glVertex2i(1250, 840);
            glVertex2i(1550, 686);
            glEnd();

        //  layer of hills

         if (isNight && rainday) {
                glColor3f(0.15f, 0.35f, 0.15f);
            } else if (isNight) {
                glColor3f(0.1f, 0.25f, 0.1f);
            } else if (rainday) {
                glColor3f(0.2f, 0.6f, 0.2f);
            } else {
                glColor3f(0.2f, 0.7f, 0.2f);
            }

            glBegin(GL_POLYGON);
            glVertex2i(100, 686);
            glVertex2i(250, 730);
            glVertex2i(500, 710);
            glVertex2i(750, 750);
            glVertex2i(1050, 720);
            glVertex2i(1300, 740);
            glVertex2i(1450, 710);
            glVertex2i(1500, 686);
            glEnd();




            ///Road
         if (isNight && rainday) {
                glColor3f(0.1f, 0.1f, 0.1f);
            } else if (isNight) {
                glColor3f(0.2f, 0.2f, 0.2f);
            } else if (rainday) {
                glColor3f(0.25f, 0.25f, 0.25f);
            } else {
                glColor3f(0.3f, 0.3f, 0.3f);
            }
            glColor3f(0.3f, 0.3f, 0.3f);
            glBegin(GL_QUADS);
            glVertex2i(0,600);
            glVertex2i(1500,600);
            glVertex2i(1500,686);
            glVertex2i(0,686);
            glEnd();

            if (isNight) {
                glColor3f(0.8f, 0.8f, 0.8f);
            } else {
                glColor3f(1.0f, 1.0f, 1.0f);
            }

            glColor3f(1.0f, 1.0f, 1.0f);
            glBegin(GL_QUADS);
            glVertex2i(0,641);
            glVertex2i(1500,641);
            glVertex2i(1500,646);
            glVertex2i(0,646);
             glEnd();

            ///Lampost

            drawLampPost(100, 685);
            drawLampPost(300, 685);
            drawLampPost(500, 685);
            drawLampPost(700, 685);
            drawLampPost(900, 685);
            drawLampPost(1100, 685);
            drawLampPost(1300, 685);



            ///car

            glPushMatrix();
            glTranslatef(carPosition, 0.0, 0.0);

            //Car Body
            glColor3f(0.33f, 0.33f, 0.33f);
            glBegin(GL_QUADS);
            glVertex2i(200, 650);
            glVertex2i(300, 650);
            glVertex2i(300, 700);
            glVertex2i(200, 700);
            glEnd();


             glColor3f(0.33f, 0.33f, 0.33f);
             glBegin(GL_QUADS);
             glVertex2i(220, 700);
             glVertex2i(280, 700);
             glVertex2i(260, 730);
             glVertex2i(240, 730);
             glEnd();


             // Left Wheel
            glPushMatrix();
            glTranslatef(220, 640, 0.0);
            glColor3f(0.0f, 0.0f, 0.0f);
            glBegin(GL_POLYGON);
            for (int i = 0; i < 360; i++) {
            float theta = i * 3.1416 / 180;
            float x = 12 * cos(theta);
            float y = 12 * sin(theta);
            glVertex2f(x, y);
        }
            glEnd();
            glPopMatrix();

            // Right Wheel
            glPushMatrix();
            glTranslatef(280, 640, 0.0);
            glColor3f(0.0f, 0.0f, 0.0f);
            glBegin(GL_POLYGON);
            for (int i = 0; i < 360; i++) {
            float theta = i * 3.1416 / 180;
            float x = 12 * cos(theta);
            float y = 12 * sin(theta);
            glVertex2f(x, y);
        }
            glEnd();
            glPopMatrix();

        glPopMatrix();

            //car1

             glPushMatrix();
            glTranslatef(bx, 0, 0);

            glColor3ub(255, 0, 0);
            glBegin(GL_POLYGON);
            glVertex2d(1410, 610);
            glVertex2d(1490, 610);
            glVertex2d(1485, 640);
            glVertex2d(1410, 640);
            glEnd();

            glColor3ub(255, 0, 0);
            glBegin(GL_POLYGON);
            glVertex2d(1420, 640);
            glVertex2d(1475, 640);
            glVertex2d(1465, 670);
            glVertex2d(1430, 670);
            glEnd();

            // car window
            glColor3ub(220, 220, 220);
            glBegin(GL_POLYGON);
            glVertex2d(1425, 640);
            glVertex2d(1445, 640);
            glVertex2d(1445, 660);
            glVertex2d(1430, 660);
            glEnd();

            // car window
            glColor3ub(220, 220, 220);
            glBegin(GL_POLYGON);
            glVertex2d(1450, 640);
            glVertex2d(1470, 640);
            glVertex2d(1465, 660);
            glVertex2d(1450, 660);
            glEnd();

            // car wheel
            glColor3ub(0, 0, 0);
            circle(10, 14, 1435, 610);
            circle(10, 14, 1465, 610);

            glColor3ub(245, 245, 245);
            circle(6, 10, 1435, 610);
            circle(6, 10, 1465, 610);

            glPopMatrix();


            /// Grass Color (Changes with Rain & Night)
        if (isNight && rainday) {
            glColor3f(0.1f, 0.3f, 0.1f);
        } else if (isNight) {
            glColor3f(0.2f, 0.4f, 0.2f);
        } else if (rainday) {
            glColor3f(0.4f, 0.6f, 0.2f);
        } else {
            glColor3f(0.6f, 0.8f, 0.2f);
        }
        glBegin(GL_QUADS);
        glVertex2i(0, 340);
        glVertex2i(1500, 340);
        glVertex2i(1500, 600);
        glVertex2i(0, 600);
        glEnd();


        /// Trees
        for (int i = 50; i < 1500; i += 150) {
            // Tree trunk
            glColor3f(0.4f, 0.2f, 0.1f);
            glBegin(GL_QUADS);
            glVertex2i(i, 340);
            glVertex2i(i + 20, 340);
            glVertex2i(i + 20, 400);
            glVertex2i(i, 400);
            glEnd();

            // Tree Leaves
            if (isNight && rainday) {
                glColor3f(0.0f, 0.2f, 0.0f);
            } else if (isNight) {
                glColor3f(0.0f, 0.3f, 0.0f);
            } else if (rainday) {
                glColor3f(0.0f, 0.4f, 0.0f);
            } else {
                glColor3f(0.0f, 0.6f, 0.0f);
            }

            glBegin(GL_TRIANGLES);
            glVertex2i(i - 30, 400);
            glVertex2i(i + 50, 400);
            glVertex2i(i + 10, 460);
            glEnd();

            glBegin(GL_TRIANGLES);
            glVertex2i(i - 25, 430);
            glVertex2i(i + 45, 430);
            glVertex2i(i + 10, 490);
            glEnd();
        }

        /// Middle Trees
        for (int i = 100; i < 1500; i += 150) {
            glColor3f(0.4f, 0.2f, 0.1f);
            glBegin(GL_QUADS);
            glVertex2i(i, 470);
            glVertex2i(i + 20, 470);
            glVertex2i(i + 20, 530);
            glVertex2i(i, 530);
            glEnd();

            // Tree Leaves (Change based on Rain & Night)
            if (isNight && rainday) {
                glColor3f(0.0f, 0.2f, 0.0f);
            } else if (isNight) {
                glColor3f(0.0f, 0.3f, 0.0f);
            } else if (rainday) {
                glColor3f(0.0f, 0.4f, 0.0f);
            } else {
                glColor3f(0.0f, 0.6f, 0.0f);
            }

            glBegin(GL_TRIANGLES);
            glVertex2i(i - 30, 530);
            glVertex2i(i + 50, 530);
            glVertex2i(i + 10, 590);
            glEnd();

            glBegin(GL_TRIANGLES);
            glVertex2i(i - 25, 560);
            glVertex2i(i + 45, 560);
            glVertex2i(i + 10, 620);
            glEnd();
        }

        /// Railway Line (Darkens at Night)
        if (isNight) {
            glColor3ub(100, 100, 100); // Darker railway at night
        } else {
            glColor3ub(150, 150, 144);
        }
            glBegin(GL_QUADS);
            glVertex2i(0, 340);
            glVertex2i(0, 365);
            glVertex2i(1500, 365);
            glVertex2i(1500, 340);
            glEnd();

        /// Upper & Lower Border Lines (Dark at Night)
        if (isNight) {
            glColor3ub(50, 50, 50);
        } else {
            glColor3ub(0, 0, 0);
        }

            glBegin(GL_QUADS);
            glVertex2i(0, 362);
            glVertex2i(1500, 362);
            glVertex2i(1500, 365);
            glVertex2i(0, 365);
            glEnd();

            glBegin(GL_QUADS);
            glVertex2i(0, 340);
            glVertex2i(1500, 340);
            glVertex2i(1500, 344);
            glVertex2i(0, 344);
            glEnd();

        /// Rail Tracks (Darker at Night)
        if (isNight) {
            glColor3ub(50, 50, 50);
        } else {
            glColor3ub(0, 0, 0);
        }
        glBegin(GL_LINES);
        for (float j = 0; j <= 1500; j += 20) {
            glVertex2i(10 + j, 340);
            glVertex2i(15 + j, 365);
        }
        glEnd();

            ///train

            //Rail Body

            glPushMatrix();
            glTranslatef(_ang_tri, 0.0, 0.0);

            glColor3f(0.192, 0.576, 0.705);
            glBegin(GL_QUADS);
            glVertex2i(100, 360);
            glVertex2i(170, 360);
            glVertex2i(170, 410);
            glVertex2i(100, 410);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(110, 385);
            glVertex2i(120, 385);
            glVertex2i(120, 400);
            glVertex2i(110, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(130, 385);
            glVertex2i(140, 385);
            glVertex2i(140, 400);
            glVertex2i(130, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(150, 385);
            glVertex2i(160, 385);
            glVertex2i(160, 400);
            glVertex2i(150, 400);
            glEnd();

            glColor3f(1.0, 0.0, 0.0);
            glBegin(GL_QUADS);
            glVertex2i(100, 370);
            glVertex2i(170, 370);
            glVertex2i(170, 375);
            glVertex2i(100, 375);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(170, 360);
            glVertex2i(176, 370);
            glVertex2i(176, 420);
            glVertex2i(170, 410);
            glEnd();


            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(101, 410);
            glVertex2i(170, 410);
            glVertex2i(176, 420);
            glVertex2i(105, 420);
            glEnd();

            glPushMatrix();
            glTranslatef(115, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
           glPopMatrix();


            glPushMatrix();
            glTranslatef(155, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
           glPopMatrix();


            glPushMatrix();
            glTranslatef(75, 0, 0);

            glColor3f(0.192, 0.576, 0.705);
            glBegin(GL_QUADS);
            glVertex2i(100, 360);
            glVertex2i(170, 360);
            glVertex2i(170, 410);
            glVertex2i(100, 410);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(110, 385);
            glVertex2i(120, 385);
            glVertex2i(120, 400);
            glVertex2i(110, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(130, 385);
            glVertex2i(140, 385);
            glVertex2i(140, 400);
            glVertex2i(130, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(150, 385);
            glVertex2i(160, 385);
            glVertex2i(160, 400);
            glVertex2i(150, 400);
            glEnd();

            glColor3f(1.0, 0.0, 0.0);
            glBegin(GL_QUADS);
            glVertex2i(100, 370);
            glVertex2i(170, 370);
            glVertex2i(170, 375);
            glVertex2i(100, 375);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(170, 360);
            glVertex2i(176, 370);
            glVertex2i(176, 420);
            glVertex2i(170, 410);
            glEnd();


            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(101, 410);
            glVertex2i(170, 410);
            glVertex2i(176, 420);
            glVertex2i(105, 420);
            glEnd();

            glPushMatrix();
            glTranslatef(115, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
           glPopMatrix();


           glPushMatrix();
            glTranslatef(155, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
            glPopMatrix();

            glPopMatrix();



            glPushMatrix();
            glTranslatef(-75, 0, 0);

            glColor3f(0.192, 0.576, 0.705);
            glBegin(GL_QUADS);
            glVertex2i(100, 360);
            glVertex2i(170, 360);
            glVertex2i(170, 410);
            glVertex2i(100, 410);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(110, 385);
            glVertex2i(120, 385);
            glVertex2i(120, 400);
            glVertex2i(110, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(130, 385);
            glVertex2i(140, 385);
            glVertex2i(140, 400);
            glVertex2i(130, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(150, 385);
            glVertex2i(160, 385);
            glVertex2i(160, 400);
            glVertex2i(150, 400);
            glEnd();

            glColor3f(1.0, 0.0, 0.0);
            glBegin(GL_QUADS);
            glVertex2i(100, 370);
            glVertex2i(170, 370);
            glVertex2i(170, 375);
            glVertex2i(100, 375);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(170, 360);
            glVertex2i(176, 370);
            glVertex2i(176, 420);
            glVertex2i(170, 410);
            glEnd();


            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(101, 410);
            glVertex2i(170, 410);
            glVertex2i(176, 420);
            glVertex2i(105, 420);
            glEnd();

            glPushMatrix();
            glTranslatef(115, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
           glPopMatrix();


            glPushMatrix();
            glTranslatef(155, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
            glPopMatrix();

            glPopMatrix();

            glPushMatrix();
            glTranslatef(150, 0, 0);

            glColor3f(0.192, 0.576, 0.705);
            glBegin(GL_QUADS);
            glVertex2i(100, 360);
            glVertex2i(170, 360);
            glVertex2i(170, 410);
            glVertex2i(100, 410);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(110, 385);
            glVertex2i(120, 385);
            glVertex2i(120, 400);
            glVertex2i(110, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(130, 385);
            glVertex2i(140, 385);
            glVertex2i(140, 400);
            glVertex2i(130, 400);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(150, 385);
            glVertex2i(160, 385);
            glVertex2i(160, 400);
            glVertex2i(150, 400);
            glEnd();

            glColor3f(1.0, 0.0, 0.0);
            glBegin(GL_QUADS);
            glVertex2i(100, 370);
            glVertex2i(170, 370);
            glVertex2i(170, 375);
            glVertex2i(100, 375);
            glEnd();

            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(170, 360);
            glVertex2i(176, 370);
            glVertex2i(176, 420);
            glVertex2i(170, 410);
            glEnd();


            glColor3f(1.0, 1.0, 1.0);
            glBegin(GL_QUADS);
            glVertex2i(101, 410);
            glVertex2i(170, 410);
            glVertex2i(176, 420);
            glVertex2i(105, 420);
            glEnd();

            glPushMatrix();
            glTranslatef(115, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
           glPopMatrix();


           glPushMatrix();
            glTranslatef(155, 352, 0.0);
            glBegin(GL_POLYGON);
            glColor3ub(109, 109, 115);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=10;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
            glPopMatrix();

            glPopMatrix();

            glColor3f(1.0, 0.0, 0.0);
            glBegin(GL_QUADS);
            glVertex2i(322, 405);
            glVertex2i(330, 405);
            glVertex2i(330, 392);
            glVertex2i(322, 392);
            glEnd();

            glColor3f(0.325, 0.101, 0.619);
            glBegin(GL_QUADS);
            glVertex2i(310, 413);
            glVertex2i(300, 413);
            glVertex2i(300, 418);
            glVertex2i(310, 418);
            glEnd();

            glPushMatrix();
            glTranslatef(303, 427, 0.0);
            glBegin(GL_POLYGON);
            glColor3f(0.709, 0.701, 0.717);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=3;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
            glPopMatrix();

            glPushMatrix();
            glTranslatef(293, 430, 0.0);
            glBegin(GL_POLYGON);
            glColor3f(0.709, 0.701, 0.717);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=4;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
            glPopMatrix();


            glPushMatrix();
            glTranslatef(283, 432, 0.0);
            glBegin(GL_POLYGON);
            glColor3f(0.709, 0.701, 0.717);
            for(int i=0;i<360;i++)
            {
                float pi=3.1416;
                float A=(i*2*pi)/200;
                float r=5;
                float x = r * cos(A);
                float y = r * sin(A);
                glVertex2f(x,y );
            }
            glEnd();
            glPopMatrix();

            glPopMatrix();

           /// Wall & Dam (Adjusts to Night & Rain)
        if (isNight && rainday) {
            glColor3f(0.3, 0.2, 0.1); // Darkest brown (Night + Rain)
        } else if (isNight) {
            glColor3f(0.4, 0.2, 0.1); // Dark brown (Night)
        } else if (rainday) {
            glColor3f(0.5, 0.25, 0.1); // Damp brown (Rain)
        } else {
            glColor3f(0.6, 0.3, 0.0); // Normal brown (Day)
        }
        glBegin(GL_POLYGON);
        glVertex2f(0.0f, 310.0f);
        glVertex2f(1500.0f, 310.0f);
        glVertex2f(1500.0f, 340.0f);
        glVertex2f(0.0f, 340.0f);
        glEnd();


        /// Dam
        if (isNight && rainday) {
            glColor3f(0.3, 0.2, 0.1);
        } else if (isNight) {
            glColor3f(0.4, 0.2, 0.1);
        } else if (rainday) {
            glColor3f(0.5, 0.25, 0.1);
        } else {
            glColor3f(0.6, 0.3, 0.0);
        }
        glBegin(GL_POLYGON);
        glVertex2f(0.0f, 310.0f);
        glVertex2f(1500.0f, 310.0f);
        glVertex2f(1500.0f, 340.0f);
        glVertex2f(0.0f, 340.0f);
        glEnd();


        if (isNight) {
            glColor3f(0.3, 0.3, 0.3);
        } else {
            glColor3f(0.5, 0.5, 0.5);
        }
        float y1 = 5.0f;
        for (float y = 310.0f; y <= 340.0f; y += y1) {
            glBegin(GL_LINES);
            glVertex2f(0.0f, y);
            glVertex2f(1500.0f, y);
            glEnd();
        }

        if (isNight) {
            glColor3f(0.3, 0.15, 0.1);
        } else {
            glColor3f(0.4, 0.2, 0.1);
        }
        for (float x = 50.0f; x <= 1450.0f; x += 100.0f) {
            glBegin(GL_LINES);
            glVertex2f(x, 310.0f); // Bottom
            glVertex2f(x, 340.0f); // Top
            glEnd();
        }





           /// Beach Color
        if (isNight && rainday) {
            glColor3f(0.4f, 0.3f, 0.2f);
        } else if (isNight) {
            glColor3f(0.6f, 0.5f, 0.3f);
        } else if (rainday) {
            glColor3f(0.8f, 0.7f, 0.5f);
        } else {
            glColor3f(0.94f, 0.85f, 0.56f);
        }

        // Draw Beach
        glBegin(GL_POLYGON);
        glVertex2f(0.0f, 250.0f);
        glVertex2f(1500.0f, 250.0f);
        glVertex2f(1500.0f, 310.0f);
        glVertex2f(0.0f, 310.0f);
        glEnd();


        /// Water Color
        if (isNight && rainday) {
            glColor3f(0.0f, 0.2f, 0.3f);
        } else if (isNight) {
            glColor3f(0.0f, 0.3f, 0.5f);
        } else if (rainday) {
            glColor3f(0.0f, 0.3f, 0.5f);
        } else {
            glColor3f(0.0f, 0.5f, 0.7f);
        }

        // Draw Water
        glBegin(GL_POLYGON);
        glVertex2f(0.0f, 0.0f);
        glVertex2f(1500.0f, 0.0f);
        glVertex2f(1500.0f, 250.0f);
        glVertex2f(0.0f, 250.0f);
        glEnd();










            ///---------->SHIP CODE <------------
            glPushMatrix();
            glBegin(GL_POLYGON);
            glColor3f(0.55f, 0.0f, 0.0f);//red
            glVertex2f(ship+150,100);
            glVertex2f(ship+530,100);
            glVertex2f(ship+500,70);
            glVertex2f(ship+170,70);
            glVertex2f(ship+150,80);

            glEnd();
            glBegin(GL_POLYGON);
            glColor3f(1.0f, 1.0f, 1.0f);//white body
            glVertex2f(ship+100,180);
            glVertex2f(ship+100,150);
            glVertex2f(ship+150,100);
            glVertex2f(ship+530,100);
            glVertex2f(ship+610,180);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//body shadow
            glVertex2f(ship+100,180);
            glVertex2f(ship+100,170);
            glVertex2f(ship+600,170);
            glVertex2f(ship+610,180);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.678f, 0.847f, 0.902f);//body window
            glVertex2f(ship+150,165);
            glVertex2f(ship+540,165);
            glVertex2f(ship+540,150);
            glVertex2f(ship+150,150);
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<20;i++){
                glColor3f(0.4f, 0.5f, 0.8f);//body window
                glVertex2f(ship+window+160,165);
                glVertex2f(ship+window+170,165);
                glVertex2f(ship+window+170,150);
                glVertex2f(ship+window+160,150);
                window+=20;
            }
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<40;i++){
                glColor3f(0.1f, 0.1f, 0.1f);//body window
                glVertex2f(ship+window+155,140);
                glVertex2f(ship+window+160,140);
                glVertex2f(ship+window+160,130);
                glVertex2f(ship+window+155,130);
                window+=10;
            }
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(1.0f, 1.0f, 1.0f);//first layer
            glVertex2f(ship+150,180);
            glVertex2f(ship+540,180);
            glVertex2f(ship+540,200);
            glVertex2f(ship+150,200);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//first layer shadow
            glVertex2f(ship+150,200);
            glVertex2f(ship+540,200);
            glVertex2f(ship+540,205);
            glVertex2f(ship+150,205);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.678f, 0.847f, 0.902f);// window
            glVertex2f(ship+150,185);
            glVertex2f(ship+540,185);
            glVertex2f(ship+540,195);
            glVertex2f(ship+150,195);
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<19;i++){
                glColor3f(0.4f, 0.5f, 0.8f);// window
                glVertex2f(ship+window+160,185);
                glVertex2f(ship+window+170,185);
                glVertex2f(ship+window+170,195);
                glVertex2f(ship+window+160,195);
                window+=20;
            }
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(1.0f, 1.0f, 1.0f);//second layer
            glVertex2f(ship+150,205);
            glVertex2f(ship+540,205);
            glVertex2f(ship+530,225);
            glVertex2f(ship+160,225);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//second layer shadow
            glVertex2f(ship+160,225);
            glVertex2f(ship+530,225);
            glVertex2f(ship+530,230);
            glVertex2f(ship+160,230);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.678f, 0.847f, 0.902f);// window
            glVertex2f(ship+160,210);
            glVertex2f(ship+530,210);
            glVertex2f(ship+530,220);
            glVertex2f(ship+160,220);
            glEnd();
            glBegin(GL_QUADS);
            window=0;
            for(int i=0;i<18;i++){
                glColor3f(0.4f, 0.5f, 0.8f);// window
                glVertex2f(ship+window+170,210);
                glVertex2f(ship+window+180,210);
                glVertex2f(ship+window+180,220);
                glVertex2f(ship+window+170,220);
                window+=20;
            }
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(1.0f, 1.0f, 1.0f);//third layer
            glVertex2f(ship+170,230);
            glVertex2f(ship+310,230);
            glVertex2f(ship+300,245);
            glVertex2f(ship+180,245);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.4f, 0.5f, 0.8f);// window
            glVertex2f(ship+180,232);
            glVertex2f(ship+300,232);
            glVertex2f(ship+293,243);
            glVertex2f(ship+187,243);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(1.0f, 1.0f, 1.0f);//chimney
            glVertex2f(ship+400,230);
            glVertex2f(ship+450,230);
            glVertex2f(ship+450,280);
            glVertex2f(ship+400,280);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.5f, 0.5f, 0.5f);//chimney shadow
            glVertex2f(ship+400,280);
            glVertex2f(ship+450,280);
            glVertex2f(ship+450,285);
            glVertex2f(ship+400,285);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(1.0f, 1.0f, 1.0f);//design
            glVertex2f(ship+210,245);
            glVertex2f(ship+210,290);
            glVertex2f(ship+250,290);
            glVertex2f(ship+280,245);
            glEnd();
            glBegin(GL_QUADS);
            glColor3f(0.0f, 0.0f, 0.5f);//design
            glVertex2f(ship+210,245);
            glVertex2f(ship+210,250);
            glVertex2f(ship+278,250);
            glVertex2f(ship+280,245);
            glEnd();
            glPopMatrix();
        }



        if(currentScenerio==2){
            glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            glClear(GL_COLOR_BUFFER_BIT);
            glLoadIdentity();
            gluOrtho2D(0,1500,0,1000);
            glMatrixMode(GL_MODELVIEW);

             ///sky///
             if(Night)
             {
               glColor3ub(64,64,80);
             }
             else
                {glColor3ub(135,206,235);}
                glBegin(GL_POLYGON);
                glVertex2f(0.0f,450.0f);
                glVertex2f(1500.0f,450.0f);
                glVertex2f(1500.0f,1000.0f);
                glVertex2f(0.0f,1000.0f);
                glEnd();

                ///plan code///


                ////plan body 1 //////


                {glColor3f(255.0f, 0.0f, 0.0f);}
                 glBegin(GL_QUADS);
                 glVertex2f(800,850);
                 glVertex2f(850,850);
                 glVertex2f(850,870);
                 glVertex2f(800,870);
                glEnd();

            //1 plan head
            glColor3ub (0, 0, 139);

                glBegin(GL_TRIANGLES);
                glVertex2f(850,850);
                glVertex2f(880,850);
                glVertex2f(850,870);
                glEnd();



                 glColor3ub(255, 0, 0);
                glBegin(GL_LINES);
                glVertex2f(881, 851);
                glVertex2f(851, 871);

                glVertex2f(851,871);
                glVertex2f(851, 851);
                glEnd();



             //1 plan tail
             glColor3ub (0,0,139);

                glBegin(GL_TRIANGLES);
                glVertex2f(800,870);
                glVertex2f(825,870);
                glVertex2f(800,890);
                glEnd();


                 glColor3ub(255, 0, 0);
                glBegin(GL_LINES);
                glVertex2f(826, 871);
                glVertex2f(801, 891);

                glVertex2f(801,891);
                glVertex2f(801, 871);
                glEnd();


            // plan window for left side 1
            if(Night)
             {
               glColor3ub(255,255,0);
             }
             else
                {glColor3f(1.0f, 1.0f, 1.0f);}
             glBegin(GL_QUADS);
             glVertex2f(805,855);
             glVertex2f(820,855);
             glVertex2f(820,865);
             glVertex2f(805,865);
            glEnd();


            // plan window for middle side
            if(Night)
             {
               glColor3ub(255,255,0);
             }
             else
                {glColor3f(1.0f, 1.0f, 1.0f);}
             glBegin(GL_QUADS);
             glVertex2f(825,855);
             glVertex2f(840,855);
             glVertex2f(840,865);
             glVertex2f(825,865);
            glEnd();


            // plan window for right side
            if(Night)
             {
               glColor3ub(255,255,0);
             }
             else
                {glColor3f(1.0f, 1.0f, 1.0f);}
             glBegin(GL_QUADS);
             glVertex2f(851,850);
             glVertex2f(859,850);
             glVertex2f(859,860);
             glVertex2f(851,860);
            glEnd();

                ////plan body 2 //////
                    glColor3f(255.0f, 0.0f, 0.0f);
                 glBegin(GL_QUADS);
                 glVertex2f(920,800);
                 glVertex2f(970,800);
                 glVertex2f(970,820);
                 glVertex2f(920,820);
                glEnd();



                //2 plan head
                glColor3ub (0, 0, 139);

                    glBegin(GL_TRIANGLES);
                    glVertex2f(970,800);
                    glVertex2f(1000,800);
                    glVertex2f(970,820);
                    glEnd();


                    glColor3ub(255, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(1001, 801);
                    glVertex2f(970, 821);

                    glVertex2f(970,821);
                    glVertex2f(971, 801);
                    glEnd();

                //2 plan tail
                 glColor3ub (0,0,139);

                    glBegin(GL_TRIANGLES);
                    glVertex2f(920,820);
                    glVertex2f(945,820);
                    glVertex2f(920,840);
                    glEnd();

                    glColor3ub(255, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(946, 821);
                    glVertex2f(921, 841);

                    glVertex2f(921,841);
                    glVertex2f(921, 821);
                    glEnd();


                // plan window for left side 2
                   if(Night)
                 {
                   glColor3ub(255,255,0);
                 }
                 else
                    {glColor3f(1.0f, 1.0f, 1.0f);}
                 glBegin(GL_QUADS);
                 glVertex2f(925,805);
                 glVertex2f(940,805);
                 glVertex2f(940,815);
                 glVertex2f(925,815);
                glEnd();




                // plan window for middle side 2
                if(Night)
                 {
                   glColor3ub(255,255,0);
                 }
                 else
                    {glColor3f(1.0f, 1.0f, 1.0f);}
                 glBegin(GL_QUADS);
                 glVertex2f(945,805);
                 glVertex2f(960,805);
                 glVertex2f(960,815);
                 glVertex2f(945,815);
                glEnd();



                // plan window for right side 2
                if(Night)
                 {
                   glColor3ub(255,255,0);
                 }
                 else
                    {glColor3f(1.0f, 1.0f, 1.0f);}
                 glBegin(GL_QUADS);
                 glVertex2f(971,800);
                 glVertex2f(979,800);
                 glVertex2f(979,810);
                 glVertex2f(971,810);
                glEnd();



                ///house
                // House Body 1st

                if(Night)
                 {
                   glColor3ub(204,102,0);
                 }
                 else
                {glColor3ub(210, 180, 140);}
                glBegin(GL_POLYGON);
                glVertex2f(150, 450);
                glVertex2f(300, 450);
                glVertex2f(300, 550);
                glVertex2f(150, 550);
                glEnd();

                // House Roof
                if(Night)
                 {
                   glColor3ub(51,25,0);
                 }
                 else

                glColor3ub(139, 69, 19);
                glBegin(GL_TRIANGLES);
                glVertex2f(140, 550);
                glVertex2f(310, 550);
                glVertex2f(225, 600);
                glEnd();



                // Windows
                if(Night)
                 {
                   glColor3ub(255,255,0);
                 }
                 else
                {glColor3ub(255, 255, 250);}
                glBegin(GL_POLYGON);
                glVertex2f(160, 520);
                glVertex2f(190, 520);
                glVertex2f(190, 540);
                glVertex2f(160, 540);
                glEnd();

             ///wind left

             // Wind Turbine - Pole right left
                glColor3ub(180,180,180); // Gray color
                glBegin(GL_POLYGON);
                glVertex2f(60, 450);
                glVertex2f(80, 450);
                glVertex2f(80, 800);
                glVertex2f(60, 800);
                glEnd();

                // Wind Turbine - Hub (Circle) left
                glColor3ub(0,0,0); // Dark gray hub
                drawCircle0(70, 810, 18, 60);

                // Wind Turbine - Blades left
                glColor3ub(255, 255, 255); // Light gray blades
                drawBlade(70, 810, 140, bladeAngle);
                drawBlade(70, 810, 140, bladeAngle + 120);
                drawBlade(70, 810, 140, bladeAngle + 240);

                // 2nd House Body
                if(Night)
                 {
                   glColor3ub(204,102,0);
                 }
                 else
                {glColor3ub(210, 180, 140);}
                glBegin(GL_POLYGON);
                glVertex2f(10, 450);
                glVertex2f(140, 450);
                glVertex2f(140, 600);
                glVertex2f(10, 600);
                glEnd();

                // 2nd House Roof
                if(Night)
                 {
                   glColor3ub(51,25,0);
                 }
                 else

                glColor3ub(139, 69, 19);
                glBegin(GL_TRIANGLES);
                glVertex2f(-20, 600);
                glVertex2f(170, 600);
                glVertex2f(67, 700);
                glEnd();

                // 2nd House Door
                if(Night)
                 {
                   glColor3ub(255,255,0);
                 }
                 else
                {glColor3ub(255, 255, 250);}
                glBegin(GL_POLYGON);
                glVertex2f(60, 450);
                glVertex2f(100, 450);
                glVertex2f(100, 520);
                glVertex2f(60, 520);
                glEnd();




                // Windows
                if(Night)
                 {
                   glColor3ub(255,255,0);
                 }
                 else
                    {glColor3ub(255, 255, 250);} // Light blue color for windows

                    // Window 1 (Left)
                    glBegin(GL_QUADS);
                    glVertex2f(20, 540);
                    glVertex2f(50, 540);
                    glVertex2f(50, 570);
                    glVertex2f(20, 570);
                    glEnd();

                    // Window 2 (Right)
                    glBegin(GL_QUADS);
                    glVertex2f(100, 540);
                    glVertex2f(130, 540);
                    glVertex2f(130, 570);
                    glVertex2f(100, 570);
                    glEnd();


                 ///wind Right

                 // Wind Turbine - Pole right
                    glColor3ub(180,180,180); // Gray color
                    glBegin(GL_POLYGON);
                    glVertex2f(250, 450);
                    glVertex2f(270, 450);
                    glVertex2f(270, 700);
                    glVertex2f(250, 700);
                    glEnd();

                    // Wind Turbine - Hub (Circle) right
                    glColor3ub(0,0,0); // Dark gray hub
                    drawCircle0(260, 710, 15, 50);

                    // Wind Turbine - Blades right
                    glColor3ub(255, 255, 255); // Light gray blades
                    drawBlade(260, 710, 120, bladeAngle);
                    drawBlade(260, 710, 120, bladeAngle + 120);
                    drawBlade(260, 710, 120, bladeAngle + 240);


                // Sun

                if(Night)
                 {
                   glColor3ub(223,223,223);
                 }
                 else
                {glColor3ub(255, 0, 0);}
                float cx = 1350.0f;
                float cy = 850.0f;
                float radius = 100.0f;
                int num_segments = 100;

                glBegin(GL_TRIANGLE_FAN);
                glVertex2f(cx, cy);
                for (int i = 0; i <= num_segments; i++) {
                    float theta = 2.0f * PI * i / num_segments;
                    float x = radius * cosf(theta);
                    float y = radius * sinf(theta);
                    glVertex2f(cx + x, cy + y);
                }
                glEnd();

            glColor3ub (34, 139, 34);

                glBegin(GL_TRIANGLES);
                glVertex2f(100,450);
                glVertex2f(110,450);
                glVertex2f(140,470);
                glEnd();

                ///Hill

                    //from left 1st hill
                    if(Night)
                 {
                   glColor3ub(150,129,117);
                 }
                 else

                {glColor3ub (255, 229, 204);}

                    glBegin(GL_TRIANGLES);
                    glVertex2f(100,450);
                    glVertex2f(500,450);
                    glVertex2f(400,650);
                    glEnd();

                    glColor3ub(0, 0, 0);
                    glBegin(GL_LINES);


                    glVertex2f(501, 451);
                    glVertex2f(401, 651);

                    glVertex2f(401, 651);
                    glVertex2f(101, 451);


                    glEnd();


                   //from 2nd hill
                      if(Night)
                 {
                   glColor3ub(150,129,117);
                 }
                 else

                {glColor3ub (255, 229, 204);}

                    glBegin(GL_TRIANGLES);
                    glVertex2f(440, 450);
                    glVertex2f(800, 450);
                    glVertex2f(700, 600);
                     glEnd();

                    glColor3ub(0, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(801, 451);
                    glVertex2f(700, 601);

                    glVertex2f(700, 601);
                    glVertex2f(441, 451);
                    glEnd();

                //3rd hill
                      if(Night)
                 {
                   glColor3ub(150,129,117);
                 }
                 else

                {glColor3ub (255, 229, 204);}

                    glBegin(GL_TRIANGLES);
                    glVertex2f(680, 450);
                    glVertex2f(1100, 450);
                    glVertex2f(850, 700);
                    glEnd();

                     glColor3ub(0, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(1101, 451);
                    glVertex2f(851, 701);

                    glVertex2f(851, 701);
                    glVertex2f(681, 451);
                    glEnd();


                //4rd hill
                      if(Night)
                 {
                   glColor3ub(150,129,117);
                 }
                 else

                {glColor3ub (255, 229, 204);}

                    glBegin(GL_TRIANGLES);
                    glVertex2f(880, 450);
                    glVertex2f(1280, 450);
                    glVertex2f(1090, 670);
                    glEnd();

                     glColor3ub(0, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(1281, 451);
                    glVertex2f(1091, 671);

                    glVertex2f(1091, 671);
                    glVertex2f(881, 451);
                    glEnd();







                //5 number hill
                      if(Night)
                 {
                   glColor3ub(150,129,117);
                 }
                 else

                {glColor3ub (255, 229, 204);}

                    glBegin(GL_TRIANGLES);
                    glVertex2f(1080, 450);
                    glVertex2f(1510, 450);
                    glVertex2f(1250,770);
                    glEnd();

                     glColor3ub(0, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(1511, 451);
                    glVertex2f(1251, 771);

                    glVertex2f(1251, 771);
                    glVertex2f(1081, 451);
                    glEnd();

                //6 number hill
                       if(Night)
                 {
                   glColor3ub(150,129,117);
                 }
                 else

                {glColor3ub (255, 229, 204);}

                    glBegin(GL_TRIANGLES);
                    glVertex2f(1070, 450);
                    glVertex2f(1700, 450);
                    glVertex2f(1470, 970);
                    glEnd();

                     glColor3ub(0, 0, 0);
                    glBegin(GL_LINES);
                    glVertex2f(1701, 451);
                    glVertex2f(1471, 971);

                    glVertex2f(1471, 971);
                    glVertex2f(1071, 451);
                    glEnd();

                ///cloud

                 // Draw clouds with translation for animation
                glPushMatrix();
                glTranslatef(cloud1PositionX, 0.0f, 0.0f);
                drawCloud1(10.0f, 900.0f); // Cloud 1
                glPopMatrix();

                glPushMatrix();
                glTranslatef(cloud2PositionX, 0.0f, 0.0f);
                drawCloud1(15.0f, 850.0f); // Cloud 2
                glPopMatrix();

                glPushMatrix();
                glTranslatef(cloud3PositionX, 0.0f, 0.0f);
                drawCloud1(20.0f, 820.0f); // Cloud 3
                glPopMatrix();



                    ///tree(grass)

                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(100,450);
                        glVertex2f(110,450);
                        glVertex2f(140,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(115,450);
                        glVertex2f(125,450);
                        glVertex2f(180,490);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(120,450);
                        glVertex2f(130,450);
                        glVertex2f(200,480);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(130,450);
                        glVertex2f(140,450);
                        glVertex2f(220,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(160,450);
                        glVertex2f(185,450);
                        glVertex2f(225,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(170,450);
                        glVertex2f(195,450);
                        glVertex2f(280,490);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(200,450);
                        glVertex2f(210,450);
                        glVertex2f(320,490);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(230,450);
                        glVertex2f(240,450);
                        glVertex2f(340,470);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(255,450);
                        glVertex2f(270,450);
                        glVertex2f(365,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(280,450);
                        glVertex2f(300,450);
                        glVertex2f(390,490);
                        glEnd();






                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(320,450);
                        glVertex2f(340,450);
                        glVertex2f(420,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(360,450);
                        glVertex2f(380,450);
                        glVertex2f(445,495);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(400,450);
                        glVertex2f(420,450);
                        glVertex2f(470,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(440,450);
                        glVertex2f(460,450);
                        glVertex2f(500,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(460,450);
                        glVertex2f(480,450);
                        glVertex2f(530,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(490,450);
                        glVertex2f(500,450);
                        glVertex2f(565,498);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(510,450);
                        glVertex2f(520,450);
                        glVertex2f(590,470);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(520,450);
                        glVertex2f(535,450);
                        glVertex2f(610,510);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(550,450);
                        glVertex2f(570,450);
                        glVertex2f(630,490);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(580,450);
                        glVertex2f(600,450);
                        glVertex2f(660,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(600,450);
                        glVertex2f(610,450);
                        glVertex2f(690,466);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(650,450);
                        glVertex2f(670,450);
                        glVertex2f(720,490);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(670,450);
                        glVertex2f(690,450);
                        glVertex2f(755,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(700,450);
                        glVertex2f(715,450);
                        glVertex2f(780,490);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(720,450);
                        glVertex2f(730,450);
                        glVertex2f(800,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(735,450);
                        glVertex2f(750,450);
                        glVertex2f(830,470);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(770,450);
                        glVertex2f(785,450);
                        glVertex2f(860,490);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(790,450);
                        glVertex2f(810,450);
                        glVertex2f(890,470);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(825,450);
                        glVertex2f(845,450);
                        glVertex2f(925,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(855,450);
                        glVertex2f(870,450);
                        glVertex2f(955,490);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(880,450);
                        glVertex2f(900,450);
                        glVertex2f(985,500);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(910,450);
                        glVertex2f(925,450);
                        glVertex2f(1020,480);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(940,450);
                        glVertex2f(960,450);
                        glVertex2f(1055,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(975,450);
                        glVertex2f(985,450);
                        glVertex2f(1090,490);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(995,450);
                        glVertex2f(1020,450);
                        glVertex2f(1125,500);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1030,450);
                        glVertex2f(1045,450);
                        glVertex2f(1155,480);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1060,450);
                        glVertex2f(1070,450);
                        glVertex2f(1190,475);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1080,450);
                        glVertex2f(1100,450);
                        glVertex2f(1220,490);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1110,450);
                        glVertex2f(1130,450);
                        glVertex2f(1260,500);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1145,450);
                        glVertex2f(1165,450);
                        glVertex2f(1290,480);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1185,450);
                        glVertex2f(1205,450);
                        glVertex2f(1320,490);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1220,450);
                        glVertex2f(1250,450);
                        glVertex2f(1355,470);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1260,450);
                        glVertex2f(1282,450);
                        glVertex2f(1380,490);
                        glEnd();


                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1300,450);
                        glVertex2f(1325,450);
                        glVertex2f(1410,480);
                        glEnd();





                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1350,450);
                        glVertex2f(1370,450);
                        glVertex2f(1440,500);
                        glEnd();





                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1375,450);
                        glVertex2f(1385,450);
                        glVertex2f(1460,480);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1390,450);
                        glVertex2f(1410,450);
                        glVertex2f(1470,470);
                        glEnd();




                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1425,450);
                        glVertex2f(1445,450);
                        glVertex2f(1500,500);
                        glEnd();



                        glColor3ub (34, 139, 34);

                        glBegin(GL_TRIANGLES);
                        glVertex2f(1460,450);
                        glVertex2f(1475,450);
                        glVertex2f(1530,490);
                        glEnd();


                    //road

                     glColor3f(0.3f, 0.3f, 0.3f);
                     glBegin(GL_QUADS);
                     glVertex2f(0,330);
                     glVertex2f(1500,330);
                     glVertex2f(1500,450);
                     glVertex2f(0,450);
                    glEnd();

                     glColor3f(1.0f, 1.0f, 1.0f);
                     glBegin(GL_QUADS);
                     glVertex2f(0,385);
                     glVertex2f(1500,385);
                     glVertex2f(1500,395);
                     glVertex2f(0,395);

                     glEnd();


                     drawCar1(); // Draw  car1

                     drawCar2(); //draw car2


            ///field
            glColor3ub(34,139,34);
            glBegin(GL_POLYGON);
            glVertex2f(0.0f,190.0f);
            glVertex2f(700.0f,190.0f);
            glVertex2f(1000.0f,330.0f);
            glVertex2f(0.0f,330.0f);
            glEnd();




            ///water
               if(Night)
             {
               glColor3ub(70,70,90);
             }
             else


            {glColor3ub(0,105,148);}
            glBegin(GL_POLYGON);
            glVertex2f(700.0f,190.0f);
            glVertex2f(1500.0f,190.0f);
            glVertex2f(1500.0f,330.0f);
            glVertex2f(1000.0f,330.0f);
            glEnd();






                glColor3ub(0,105,148);
                glBegin(GL_POLYGON);
                glVertex2f(0.0f,0.0f);
                glVertex2f(1500.0f,0.0f);
                glVertex2f(1500.0f,190.0f);
                glVertex2f(0.0f,190.0f);
                glEnd();


                // boat
                   if(Night)
             {
               glColor3ub(0,9,17);
             }
             else



                {glColor3ub(139, 69, 19);}
                glBegin(GL_POLYGON);
                glVertex2f(1200.0f, 230.0f);
                glVertex2f(1400.0f, 230.0f);
                glVertex2f(1450.0f, 260.0f);
                glVertex2f(1150.0f, 260.0f);
                glEnd();



                // sail pole (right side)
                glColor3ub(105, 105, 105);
                glBegin(GL_POLYGON);
                glVertex2f(1275.0f, 260.0f);
                glVertex2f(1285.0f, 260.0f);
                glVertex2f(1285.0f, 360.0f);
                glVertex2f(1275.0f, 360.0f);
                glEnd();

                // sail (right side)
                   if(Night)
             {
               glColor3ub(255,255,0);
             }
             else

                {glColor3ub(255, 255, 255);}
                glBegin(GL_TRIANGLES);
                glVertex2f(1285.0f, 360.0f);
                glVertex2f(1285.0f, 260.0f);
                glVertex2f(1350.0f, 310.0f);
                glEnd();






                //---------->SHIP CODE <------------
                glPushMatrix();
                glBegin(GL_POLYGON);
                glColor3f(0.55f, 0.0f, 0.0f);//red
                glVertex2f(ship+150,100);
                glVertex2f(ship+530,100);
                glVertex2f(ship+500,70);
                glVertex2f(ship+170,70);
                glVertex2f(ship+150,80);

                glEnd();
                glBegin(GL_POLYGON);
                glColor3f(1.0f, 1.0f, 1.0f);//white body
                glVertex2f(ship+100,180);
                glVertex2f(ship+100,150);
                glVertex2f(ship+150,100);
                glVertex2f(ship+530,100);
                glVertex2f(ship+610,180);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.0f, 0.0f, 0.5f);//body shadow
                glVertex2f(ship+100,180);
                glVertex2f(ship+100,170);
                glVertex2f(ship+600,170);
                glVertex2f(ship+610,180);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.678f, 0.847f, 0.902f);//body window
                glVertex2f(ship+150,165);
                glVertex2f(ship+540,165);
                glVertex2f(ship+540,150);
                glVertex2f(ship+150,150);
                glEnd();
                glBegin(GL_QUADS);
                window=0;
                for(int i=0;i<20;i++){
                    glColor3f(0.4f, 0.5f, 0.8f);//body window
                    glVertex2f(ship+window+160,165);
                    glVertex2f(ship+window+170,165);
                    glVertex2f(ship+window+170,150);
                    glVertex2f(ship+window+160,150);
                    window+=20;
                }
                glEnd();
                glBegin(GL_QUADS);
                window=0;
                for(int i=0;i<40;i++){
                    glColor3f(0.1f, 0.1f, 0.1f);//body window
                    glVertex2f(ship+window+155,140);
                    glVertex2f(ship+window+160,140);
                    glVertex2f(ship+window+160,130);
                    glVertex2f(ship+window+155,130);
                    window+=10;
                }
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(1.0f, 1.0f, 1.0f);//first layer
                glVertex2f(ship+150,180);
                glVertex2f(ship+540,180);
                glVertex2f(ship+540,200);
                glVertex2f(ship+150,200);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.0f, 0.0f, 0.5f);//first layer shadow
                glVertex2f(ship+150,200);
                glVertex2f(ship+540,200);
                glVertex2f(ship+540,205);
                glVertex2f(ship+150,205);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.678f, 0.847f, 0.902f);// window
                glVertex2f(ship+150,185);
                glVertex2f(ship+540,185);
                glVertex2f(ship+540,195);
                glVertex2f(ship+150,195);
                glEnd();
                glBegin(GL_QUADS);
                window=0;
                for(int i=0;i<19;i++){
                    glColor3f(0.4f, 0.5f, 0.8f);// window
                    glVertex2f(ship+window+160,185);
                    glVertex2f(ship+window+170,185);
                    glVertex2f(ship+window+170,195);
                    glVertex2f(ship+window+160,195);
                    window+=20;
                }
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(1.0f, 1.0f, 1.0f);//second layer
                glVertex2f(ship+150,205);
                glVertex2f(ship+540,205);
                glVertex2f(ship+530,225);
                glVertex2f(ship+160,225);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.0f, 0.0f, 0.5f);//second layer shadow
                glVertex2f(ship+160,225);
                glVertex2f(ship+530,225);
                glVertex2f(ship+530,230);
                glVertex2f(ship+160,230);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.678f, 0.847f, 0.902f);// window
                glVertex2f(ship+160,210);
                glVertex2f(ship+530,210);
                glVertex2f(ship+530,220);
                glVertex2f(ship+160,220);
                glEnd();
                glBegin(GL_QUADS);
                window=0;
                for(int i=0;i<18;i++){
                    glColor3f(0.4f, 0.5f, 0.8f);// window
                    glVertex2f(ship+window+170,210);
                    glVertex2f(ship+window+180,210);
                    glVertex2f(ship+window+180,220);
                    glVertex2f(ship+window+170,220);
                    window+=20;
                }
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(1.0f, 1.0f, 1.0f);//third layer
                glVertex2f(ship+170,230);
                glVertex2f(ship+310,230);
                glVertex2f(ship+300,245);
                glVertex2f(ship+180,245);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.4f, 0.5f, 0.8f);// window
                glVertex2f(ship+180,232);
                glVertex2f(ship+300,232);
                glVertex2f(ship+293,243);
                glVertex2f(ship+187,243);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(1.0f, 1.0f, 1.0f);//chimney
                glVertex2f(ship+400,230);
                glVertex2f(ship+450,230);
                glVertex2f(ship+450,280);
                glVertex2f(ship+400,280);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.5f, 0.5f, 0.5f);//chimney shadow
                glVertex2f(ship+400,280);
                glVertex2f(ship+450,280);
                glVertex2f(ship+450,285);
                glVertex2f(ship+400,285);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(1.0f, 1.0f, 1.0f);//design
                glVertex2f(ship+210,245);
                glVertex2f(ship+210,290);
                glVertex2f(ship+250,290);
                glVertex2f(ship+280,245);
                glEnd();
                glBegin(GL_QUADS);
                glColor3f(0.0f, 0.0f, 0.5f);//design
                glVertex2f(ship+210,245);
                glVertex2f(ship+210,250);
                glVertex2f(ship+278,250);
                glVertex2f(ship+280,245);
                glEnd();
                glPopMatrix();

                glEnd();
            }

        if(currentScenerio==3){
                    if (isDay) {
                        glClearColor(0.4f, 0.8f, 1.0f, 1.0f); // Light blue sky
                    }
                     else {
                       glClearColor(0.05f, 0.05f, 0.2f, 1.0f); // Dark blue sky
                    }
                     if (isDay) {
                     glClearColor(0.28f, 0.876f, 0.904f,0.0f);// Set background color to sky blue
                     }
                     else{
                         glClearColor(0.05f, 0.05f, 0.2f, 1.0f);// Dark blue background
                     }

                    glClear(GL_COLOR_BUFFER_BIT);
                    glLoadIdentity();
                    gluOrtho2D(0, 1500, 0, 1000);

                    /// Night sky gradient
                    glBegin(GL_QUADS);
                    glColor3f(0.0f, 0.0f, 0.2f); // Top dark blue
                    glVertex2i(0, 1000);
                    glVertex2i(1500, 1000);
                    glColor3f(0.1f, 0.1f, 0.3f); // Bottom dark blue
                    glVertex2i(1500, 500);
                    glVertex2i(0, 500);
                    glEnd();


                     glBegin(GL_QUADS);
                     if (isDay) {
                     glColor3f(1.0f, 1.0f, 0.0f); // Yellow color for the sun
                    glColor3f(0.0f, 0.5f, 1.0f); // Top color (blue)
                    glVertex2i(0, 1000);
                    glVertex2i(1500, 1000);
                    glColor3f(0.5f, 0.8f, 1.0f); // Bottom color (light blue)
                    glVertex2i(1500, 500);
                    glVertex2i(0, 500);
                    glEnd();
                     }
                     else{
                    glColor3f(0.0f, 0.0f, 0.2f);
                    glVertex2i(0, 1000);
                    glVertex2i(1500, 1000);
                    glColor3f(0.5f, 0.8f, 1.0f); // Bottom color (light blue)
                    glVertex2i(1500, 500);
                    glVertex2i(0, 500);
                    glEnd();
                     }

                      if(night){
                        drawStars();
                     }

                    //sun
                    glPushMatrix();
                    float radius = 100.0f;
                    int num_segments = 100;
                    glTranslatef(250.0f, 645.0f,0.0f);
                    glBegin(GL_POLYGON);
                    if(isDay)glColor3f(1.0f, 1.0f, 0.0f); // Yellow color for the sun
                    else glColor3f(0.9f, 0.9f, 0.7f);
                    for (int i = 0; i < num_segments; i++) {
                        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
                        float x = radius * cosf(theta);
                        float y = radius * sinf(theta);
                        glVertex2f(x, y);
                    }
                    glEnd();
                    glPopMatrix();


                    // Draw multiple clouds
                    drawCloud3(400, 900);
                    drawCloud3(440, 850);
                    drawCloud3(550, 800);
                    drawCloud3(550, 750);
                     drawCloud3(450, 900);

                // drawCloud(300, 900);
                    drawCloud3(500, 850);
                    drawCloud3(550, 800);
                    drawCloud3(600, 750);
                    drawCloud3(590, 780);

                    drawCloud3(1170, 770);
                    drawCloud3(1100, 800);
                    drawCloud3(1100, 750);
                    drawCloud3(1150, 750);


                    glutTimerFunc(25, clouds, 0);
                    glutPostRedisplay();

                    glFlush();

                    // Moving Birds
                    drawBird(birdX, 750);
                    drawBird(birdX + 50, 770);
                    drawBird(birdX + 100, 740);


                             ///hill -1 code/////////
                         glPushMatrix();
                         glTranslatef(100.0,0.0,0.0);
                         glColor3f(0.604f,0.752f,0.392f);//bottol  green color
                        glBegin(GL_POLYGON);
                     glVertex2f(0,450);
                      glVertex2f(30,520);
                        glVertex2f(145,450);
                       glEnd();

                         ///hill -2 code
                       glColor3f(0.0f,0.424f,0.312f);//bottol  green color
                        glBegin(GL_POLYGON);
                     glVertex2f(100,450);
                      glVertex2f(170,550);
                        glVertex2f(300,450);
                       glEnd();

                       glColor3f(0.0f,0.424f,0.312f);//bottol  green color
                        glBegin(GL_POLYGON);
                     glVertex2f(200,450);
                      glVertex2f(400,520);
                        glVertex2f(600,450);
                       glEnd();
                       glPopMatrix();

                ///   hill-4
                    glColor3f(0.0f,0.424f,0.312f);//bottol  green color
                    glBegin(GL_POLYGON);
                    glVertex2i(200, 500);
                    glVertex2i(400, 800);
                    glVertex2i(750, 500);
                    glEnd();

                    /// hill-5
                    glColor3f(0.316f,0.484f,0.264f);//Fern Green color
                    glBegin(GL_POLYGON);
                    glVertex2f(700, 500);
                    glVertex2f(750, 850);
                    glVertex2f(1250, 500);
                    glEnd();

                    ///  hill-6
                    glColor3f(0.512f,0.512f,0.0f);//Olive  green color
                    glBegin(GL_POLYGON);
                    glVertex2f(1200, 500);
                    glVertex2f(1400, 750);
                    glVertex2f(1600, 500);
                    glEnd();

                     ///  hill-7
                    glColor3f(0.0f,0.308f,0.148f);// Green color
                    glBegin(GL_POLYGON);
                    glVertex2f(00, 500);
                    glVertex2f(5,830);
                    glVertex2f(350, 500);
                    glEnd();

                    ///hill-8
                     glColor3f(0.0f,0.424f,0.312f);//bottol  green color
                    glBegin(GL_POLYGON);
                    glVertex2f(610, 500);
                    glVertex2f(670,700);
                    glVertex2f(700, 715);
                     glVertex2f(750, 680);
                    glVertex2f(735,500);
                    //glVertex2f(700, 715);
                    glEnd();

                    /// Land
                    glBegin(GL_POLYGON);
                    if(isDay){
                        glColor3f(0.952f,0.928f,0.68f);// land yellow color
                   // glBegin(GL_POLYGON);
                    glVertex2f(1500, 500);
                    glVertex2f(500, 500);
                    glVertex2f(1500, 270);
                    glEnd();
                    }
                    else{
                            glColor3f(0.2f, 0.2f, 0.1f); // Dark land
                         glVertex2f(1500, 500);
                    glVertex2f(500, 500);
                    glVertex2f(1500, 270);
                    glEnd();
                    }

                    // Hills
                    glColor3f(0.0f, 0.3f, 0.0f); // Dark green hills
                    glBegin(GL_POLYGON);
                    glVertex2f(200, 500);
                    glVertex2f(400, 800);
                    glVertex2f(750, 500);
                    glEnd();

                    glColor3f(0.1f, 0.4f, 0.1f);
                    glBegin(GL_POLYGON);
                    glVertex2f(700, 500);
                    glVertex2f(750, 850);
                    glVertex2f(1250, 500);
                    glEnd();

                    ///Tree Root1- 02
                       glColor3f(0.676f,0.392f,0.064f);//Brown
                    glBegin(GL_POLYGON);
                    glVertex2f(1500,450);
                     glVertex2f(1450,560);
                      glVertex2f(1500,570);
                       //glVertex2f(0,1000);
                       glEnd();


                       ///Tree Leaf1- 02(lower side)
                       glColor3f(0.676f,0.392f,0.064f);//Brown
                    glBegin(GL_POLYGON);
                    glVertex2f(1450,560);
                     glVertex2f(1430,510);
                      glVertex2f(1420,520);
                      glVertex2f(1420,475);
                     glVertex2f(1411,480);
                      glVertex2f(1405,445);
                    glVertex2f(1390,400);

                      glEnd();


                     glColor3f(0.0f,0.308f,0.148f);// Green color
                    glBegin(GL_POLYGON);
                     glVertex2f(1390,400);
                    glVertex2f(1360,450);
                     glVertex2f(1355,440);
                      glVertex2f(1360,485);
                      glVertex2f(1345,480);
                     glVertex2f(1365,520);
                      glVertex2f(1350,520);
                      glVertex2f(1380,545);
                     glVertex2f(1410,565);
                      glVertex2f(1450,560);

                       glEnd();

                       ///Tree Leaf2- 02(upper side)
                       glColor3f(0.0f,0.308f,0.148f);// Green color
                    glBegin(GL_POLYGON);
                    glVertex2f(1355,510);
                     glVertex2f(1330,490);
                      glVertex2f(1290,490);
                      glVertex2f(1300,520);
                     glVertex2f(1315,540);
                      glVertex2f(1300,535);
                    glVertex2f(1325,550);
                         glVertex2f(1340,560);
                      glVertex2f(1330,565);
                      glVertex2f(1350,570);
                     glVertex2f(1370,575);
                      glVertex2f(1360,580);
                    glVertex2f(1395,590);
                     glVertex2f(1420,585);
                    glVertex2f(1450,570);

                      glEnd();


                       ///Tree Leaf3- 02(lower side)
                       glColor3f(0.0f,0.308f,0.148f);// Green color
                    glBegin(GL_POLYGON);
                    glVertex2f(1395,570);
                     glVertex2f(1405,580);
                      glVertex2f(1355,575);
                      glVertex2f(1365,585);
                     glVertex2f(1315,540);
                      glVertex2f(1320,580);
                    glVertex2f(1330,595);
                         glVertex2f(1275,590);
                          glVertex2f(1300,620);
                      glVertex2f(1320,630);
                     glVertex2f(1310,635);
                      glVertex2f(1340,640);
                    glVertex2f(1360,630);
                     glVertex2f(1355,645);
                    glVertex2f(1375,640);
                     glVertex2f(1390,630);
                    glVertex2f(1390,645);
                     glVertex2f(1410,630);
                    glVertex2f(1425,620);
                      glVertex2f(1440,595);
                    glVertex2f(1450,550);
                         glEnd();


                           ///Tree Leaf4- 02(lower side)
                       glColor3f(0.0f,0.308f,0.148f);// Green color
                    glBegin(GL_POLYGON);
                    glVertex2f(1500,550);
                     glVertex2f(1460,555);
                      glVertex2f(1470,560);
                      glVertex2f(1480,590);
                     glVertex2f(1500,600);


                         glEnd();


                           ///Tree Leaf4- 02(lower side)
                       glColor3f(0.0f,0.308f,0.148f);// Green color
                    glBegin(GL_POLYGON);
                    glVertex2f(1420,620);
                     glVertex2f(1410,630);
                      glVertex2f(1420,640);
                      glVertex2f(1430,635);
                     glVertex2f(1435,655);
                      glVertex2f(1445,665);
                    glVertex2f(1450,657);
                         glVertex2f(1470,670);
                          glVertex2f(1470,650);
                      glVertex2f(1465,660);
                       glVertex2f(1460,645);
                      glVertex2f(1450,630);
                    glVertex2f(1450,640);
                         glVertex2f(1470,620);
                          glVertex2f(1490,625);
                      glVertex2f(1500,600);
                        glVertex2f(1490,660);

                         glEnd();

                         ///Umbrella pink
                            glColor3f(0.924f,0.336f,0.512f);// Pink color
                    glBegin(GL_POLYGON);
                    glVertex2f(1200,540);
                     glVertex2f(1095,530);
                      glVertex2f(960,490);
                      glVertex2f(950,460);
                     glVertex2f(965,440);
                      glVertex2f(975,460);
                       glVertex2f(1200,540);
                    glVertex2f(1070,435);
                         glVertex2f(1080,415);
                          glVertex2f(1160,410);
                           glVertex2f(1200,540);
                            glVertex2f(1280,430);
                      glVertex2f(1290,415);
                      glVertex2f(1400,415);
                     glVertex2f(1420,440);
                       glVertex2f(1200,540);
                      glVertex2f(1340,525);
                      glVertex2f(1440,500);
                       glVertex2f(1465,485);
                      glVertex2f(1467,482);
                     glVertex2f(1465,470);
                      glVertex2f(1200,540);

                       glEnd();


                         ///Umbrella-blue part
                            glColor3f(0.1f,0.1f,0.448f);// blue color
                    glBegin(GL_POLYGON);
                    glVertex2f(1200,540);
                    glVertex2f(975,460);
                       glVertex2f(965,440);
                    glVertex2f(1060,417);
                         glVertex2f(1070,433);
                           glVertex2f(1200,540);
                          glVertex2f(1160,410);
                           glVertex2f(1205,400);
                            glVertex2f(1216,403);
                      glVertex2f(1265,405);
                      glVertex2f(1280,430);
                       glVertex2f(1200,540);
                     glVertex2f(1420,440);
                       glVertex2f(1200,540);
                      glVertex2f(1420,440);
                      glVertex2f(1425,425);
                       glVertex2f(1475,445);
                      glVertex2f(1480,462);
                     glVertex2f(1370,510);
                      glVertex2f(1200,540);

                       glEnd();


                         ///Umbrella-stand part
                            glColor3f(0.0f,0.0f,0.0f);// white color
                    glBegin(GL_POLYGON);
                    glVertex2f(1200,400);
                    glVertex2f(1205,340);
                       glVertex2f(1215,340);
                    glVertex2f(1215,400);

                      glEnd();


                       ///Seaweed
                       if (isDay) glColor3f(0.984f,0.848f,0.88f);// pink color
                        else glColor3f(0.1f, 0.1f, 0.4f); // Dark blue
                    glBegin(GL_POLYGON);
                    glVertex2f(920,320);
                    glVertex2f(910,290);
                       glVertex2f(875,375);
                    glVertex2f(895,255);
                         glVertex2f(887,223);
                           glVertex2f(920,245);
                          glVertex2f(955,220);
                           glVertex2f(945,260);
                            glVertex2f(970,280);
                      glVertex2f(937,290);
                      glVertex2f(920,320);
                       glEnd();

                glFlush();

                ///......................Ship..........................///


                   glPushMatrix();
                            glBegin(GL_POLYGON);
                            if(night) glColor3f(0.275f, 0.0f, 0.0f);
                            else glColor3f(0.55f, 0.0f, 0.0f);//red
                            glVertex2f(ship+150,100);
                            glVertex2f(ship+530,100);
                            glVertex2f(ship+500,70);
                            glVertex2f(ship+170,70);
                            glVertex2f(ship+150,80);
                            glEnd();
                            glBegin(GL_POLYGON);
                            if(night) glColor3f(0.4f, 0.4f, 0.5f);
                            else glColor3f(0.9f, 0.9f, 0.9f);//white body
                            glVertex2f(ship+100,180);
                            glVertex2f(ship+100,150);
                            glVertex2f(ship+150,100);
                            glVertex2f(ship+530,100);
                            glVertex2f(ship+610,180);
                            glEnd();
                            glBegin(GL_QUADS);
                            glColor3f(0.0f, 0.0f, 0.5f);//body shadow
                            glVertex2f(ship+100,180);
                            glVertex2f(ship+100,170);
                            glVertex2f(ship+600,170);
                            glVertex2f(ship+610,180);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.2f, 0.3f, 0.4f);
                            else glColor3f(0.4f, 0.6f, 0.8f);//body window
                            glVertex2f(ship+150,165);
                            glVertex2f(ship+540,165);
                            glVertex2f(ship+540,150);
                            glVertex2f(ship+150,150);
                            glEnd();
                            glBegin(GL_QUADS);
                            window=0;
                            for(int i=0;i<20;i++){
                                if(night)glColor3f(1.0f, 0.9f, 0.6f);
                                    else glColor3f(0.678f, 0.847f, 0.902f);//body window
                                glVertex2f(ship+window+160,165);
                                glVertex2f(ship+window+170,165);
                                glVertex2f(ship+window+170,150);
                                glVertex2f(ship+window+160,150);
                                window+=20;
                            }
                            glEnd();
                            glBegin(GL_QUADS);
                            window=0;
                            for(int i=0;i<40;i++){
                                glColor3f(0.1f, 0.1f, 0.1f);//body window
                                glVertex2f(ship+window+155,140);
                                glVertex2f(ship+window+160,140);
                                glVertex2f(ship+window+160,130);
                                glVertex2f(ship+window+155,130);
                                window+=10;
                            }
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.4f, 0.4f, 0.5f);
                            else glColor3f(0.9f, 0.9f, 0.9f);//first layer
                            glVertex2f(ship+150,180);
                            glVertex2f(ship+540,180);
                            glVertex2f(ship+540,200);
                            glVertex2f(ship+150,200);
                            glEnd();
                            glBegin(GL_QUADS);
                            glColor3f(0.0f, 0.0f, 0.5f);//first layer shadow
                            glVertex2f(ship+150,200);
                            glVertex2f(ship+540,200);
                            glVertex2f(ship+540,205);
                            glVertex2f(ship+150,205);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.2f, 0.3f, 0.4f);
                            else glColor3f(0.4f, 0.6f, 0.8f);//window
                            glVertex2f(ship+150,185);
                            glVertex2f(ship+540,185);
                            glVertex2f(ship+540,195);
                            glVertex2f(ship+150,195);
                            glEnd();
                            glBegin(GL_QUADS);
                            window=0;
                            for(int i=0;i<19;i++){
                                if(night)glColor3f(1.0f, 0.9f, 0.6f);
                                    else glColor3f(0.678f, 0.847f, 0.902f);// window
                                glVertex2f(ship+window+160,185);
                                glVertex2f(ship+window+170,185);
                                glVertex2f(ship+window+170,195);
                                glVertex2f(ship+window+160,195);
                                window+=20;
                            }
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.4f, 0.4f, 0.5f);
                            else glColor3f(0.9f, 0.9f, 0.9f);//second layer
                            glVertex2f(ship+150,205);
                            glVertex2f(ship+540,205);
                            glVertex2f(ship+530,225);
                            glVertex2f(ship+160,225);
                            glEnd();
                            glBegin(GL_QUADS);
                            glColor3f(0.0f, 0.0f, 0.5f);//second layer shadow
                            glVertex2f(ship+160,225);
                            glVertex2f(ship+530,225);
                            glVertex2f(ship+530,230);
                            glVertex2f(ship+160,230);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.2f, 0.3f, 0.4f);
                            else glColor3f(0.4f, 0.6f, 0.8f);//window
                            glVertex2f(ship+160,210);
                            glVertex2f(ship+530,210);
                            glVertex2f(ship+530,220);
                            glVertex2f(ship+160,220);
                            glEnd();
                            glBegin(GL_QUADS);
                            window=0;
                            for(int i=0;i<18;i++){
                                if(night)glColor3f(1.0f, 0.9f, 0.6f);
                                    else glColor3f(0.678f, 0.847f, 0.902f);// window
                                glVertex2f(ship+window+170,210);
                                glVertex2f(ship+window+180,210);
                                glVertex2f(ship+window+180,220);
                                glVertex2f(ship+window+170,220);
                                window+=20;
                            }
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.4f, 0.4f, 0.5f);
                            else glColor3f(0.9f, 0.9f, 0.9f);//third layer
                            glVertex2f(ship+170,230);
                            glVertex2f(ship+310,230);
                            glVertex2f(ship+300,245);
                            glVertex2f(ship+180,245);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night)glColor3f(1.0f, 0.9f, 0.6f);
                            else glColor3f(0.678f, 0.847f, 0.902f);
                            glVertex2f(ship+180,232);
                            glVertex2f(ship+300,232);
                            glVertex2f(ship+293,243);
                            glVertex2f(ship+187,243);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.4f, 0.4f, 0.5f);
                            else glColor3f(0.9f, 0.9f, 0.9f);//chimney
                            glVertex2f(ship+400,230);
                            glVertex2f(ship+450,230);
                            glVertex2f(ship+450,280);
                            glVertex2f(ship+400,280);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.2f, 0.2f, 0.2f);
                            else glColor3f(0.5f, 0.5f, 0.5f);//chimney shadow
                            glVertex2f(ship+400,280);
                            glVertex2f(ship+450,280);
                            glVertex2f(ship+450,285);
                            glVertex2f(ship+400,285);
                            glEnd();
                            glBegin(GL_QUADS);
                            if(night) glColor3f(0.4f, 0.4f, 0.5f);
                            else glColor3f(0.9f, 0.9f, 0.9f);//design
                            glVertex2f(ship+210,245);
                            glVertex2f(ship+210,290);
                            glVertex2f(ship+250,290);
                            glVertex2f(ship+280,245);
                            glEnd();
                            glBegin(GL_QUADS);
                            glColor3f(0.0f, 0.0f, 0.5f);//design
                            glVertex2f(ship+210,245);
                            glVertex2f(ship+210,250);
                            glVertex2f(ship+278,250);
                            glVertex2f(ship+280,245);
                            glEnd();



                    glTranslatef(-0.1f,-0.1f, 0.0f);
                     glBegin(GL_POLYGON);
                    glColor3f(0.0f, 0.0f, 0.0f);
                    float angle44;
                    for (int i=0;i<360;i++)
                    {
                        angle44=i*3.1416/180;
                        glVertex2f(0.8+0.04*cos(angle44),0.7+0.02*sin(angle44));

                    }
                    glEnd();

            }


glutSwapBuffers();
}

void updateLightPosition() {
    light += step;
    if (light >= 300) {
        step = -2;
    }
    if (light <= 0) {
       step = 2;
    }
}
void update(int value){
    if(currentScenerio==0){
        c1+=3;
        c2-=3;
        car+=5;
        car1-=6;
        if(car>1500) car=-200;
        if(car1<-2100) car1=600;
        if(c1>1500) c1=-275;
        if(c2<0) c2=1500;
        if(lighthouse){
            updateLightPosition();
        }

        if(active){
        ship+=5;
        }
        glutPostRedisplay();
        glutTimerFunc(20,update,0);
    }

    }
void update1(int value){

    if(active){
    ship+=5;
    }
    glutPostRedisplay();
    glutTimerFunc(20,update1,0);
}

void updateTrain(int value) {
    if (moving) {
        _ang_tri += 6.0; // Move train

        // Reset position when train goes out of screen
        if (_ang_tri > 1500) {
            _ang_tri = -200;  // Reset train to the left
        }

        glutPostRedisplay();
        glutTimerFunc(20, updateTrain, 0);
    }
}
void timer(int value) {
    carPosition -= 2.0f; // Move car to the left
    if (carPosition < -200) carPosition = 1500; // Reset position if off-screen
    //_ang_tri += 3.0f; // Move train to right
    //if (_ang_tri > 1500) _ang_tri = -300; // Reset train position

     bx += 2.8f;
    if (bx > 0){
        bx = -1500;}

    // Move clouds to the right
    cloud1PosX += cloudSpeed;
    cloud2PosX += cloudSpeed;

    // Reset position when clouds go off-screen
    if (cloud1PosX > 1500) {
        cloud1PosX = -100; // Reset cloud 1
    }
    if (cloud2PosX > 1500) {
        cloud2PosX = -100; // Reset cloud 2
    }

    glutPostRedisplay(); // Redraw scene
    glutTimerFunc(16, timer, 0); // Call this function again after 16ms
}
void timer2(int value) {

    bladeAngle += 4.0; // Rotate blades speed
    if (bladeAngle >= 360) {
        bladeAngle -= 360;}

     // Move clouds to the right
    cloud1PositionX += 3.0f;
    cloud2PositionX += 3.0f;
    cloud3PositionX += 3.0f;

    // Reset clouds' positions when they move out of bounds
    if (cloud1PositionX > 1500.0f) cloud1PositionX = -100.0f;
    if (cloud2PositionX > 1500.0f) cloud2PositionX = -100.0f;
    if (cloud3PositionX > 1500.0f) cloud3PositionX = -100.0f;

    /*carPositionX += 4.0f; //  car1 position
    if (carPositionX > 1300) {
        carPositionX = -400.0f;}*/

        car2 += 5.0f; //  car2
    if (car2> 800) {
        car2 = -1300.0f;
    }


    glutPostRedisplay();
    glutTimerFunc(16, timer2, 0);
}

void idle() {
    timeElapsed += 0.05f;
    glutPostRedisplay();
}

void Rain(int value) {
    if (rainday) {
        _rain += 5.0f;
        //glClear(GL_COLOR_BUFFER_BIT);
        glColor3f(1.0, 1.0, 1.0);

        for (int i = 0; i < 1000; i++) {
            int x = rand() % 1500;
            int y = rand() % 1000;

            glBegin(GL_LINES);
            glVertex2d(x, y);
            glVertex2d(x, y - 10); // Adjusted to give a downward rain effect
            glEnd();
        }
        glutTimerFunc(50, Rain, 0);
    }
    //glutPostRedisplay();
    else{
        return;
    }

    glFlush();
    glutSwapBuffers();
}


// Animation update function
void update3(int value) {

    cloudX += 1;
    if (cloudX > 1500) cloudX = -300;

    sunY -= 0.1f;
    if (sunY < 700) sunY = 800;

    if (!isDay) {
        if (moonGoingDown) {
            moonY -= 0.2f;

            if (moonY < 700) moonGoingDown = false;
        } else {
            moonY += 0.2f;
            if (moonY > 800) moonGoingDown = true;
        }
    }

    // Bird Animation (flapping wings and moving)
    birdFlap = (birdFlap == 5) ? -5 : 5;
    birdX += 2;
    if (birdX > 1500) birdX = -100;

    glutPostRedisplay();
    glutTimerFunc(25, update3, 0);
}


//keyboard
void handleKeyboard(unsigned char key, int x, int y) {
    if (key == '1') {
            if(currentScenerio != 0){
                    ship=0;active=false;night=false;
                currentScenerio = 0;
                glutTimerFunc(20, update, 0);
            }

    } else if (key == '2') {
          ship=0;active=false;
        if(currentScenerio!=1){
            currentScenerio = 1;
            glutIdleFunc(idle);
            glutTimerFunc(0, timer, 0);
        }
    }
    else if(key=='3'){
              ship=0;active=false;
            rainday = false;
        if(currentScenerio!=2){
            currentScenerio = 2;
            glutIdleFunc(idle);
            glutTimerFunc(0, timer2, 0);
        }
    }
    else if(key == '4'){
          ship=0;active=false;night=false;isDay=true;
        if(currentScenerio!=3){
            currentScenerio=3;
            glutTimerFunc(20, update3, 0);
        }
    }

    if (currentScenerio == 0) {

        if (key == 's') { // start
            active = true;
        }
        if (key == 'r') { // reset
            ship = 0;
            active = false;
        }
        if (key == 'd') { // day
            night = false;
        }
        if (key == 'n') { // night
            night = true;
        }
    }

    if (currentScenerio == 1) {
        if (key == 's') { // start
            active = true;
            if(active && !timerRunning){
            timerRunning=true;
            glutTimerFunc(20, update1, 0);
            }
        }

        if (key == 'r') { // reset
            ship = 0;
            active = false;
        }
        if (key == 'n') { // night
            isNight = true;
        }
        if (key == 'd') { // day
            isNight = false;
        }
        if (key == 'c') { // start rain
            if(!rainday){
                rainday = true;
                Rain(_rain);
            }
            else{
                rainday = false;
            }
        }

    }
    if(currentScenerio==2){
        if (key == 's') { //start
            active = true;
            if(active && !timerRunning){
            timerRunning=true;
            glutTimerFunc(20, update1, 0);
            }
        }
        if (key == 'r') { //reset
            ship=0;
            active=false;
        }
          if (key == 'n') { // (night)
            Night=true;
        }
          if (key == 'd') { // (day)
            Night=false;
        }
    }
    if(currentScenerio==3){
         if (key == 'r') { // reset
            ship = 0;
            active = false;
        }
        if (key == 'd') { ///Day
            isDay = true;
            night=false;
        }
        if (key == 'n') {///Night
            isDay = false;
            night=true;
        }
    }

    glutPostRedisplay();
}
void mouse(int button, int state, int x, int y) {
    if(currentScenerio==0){
        if(night){
            if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
                lighthouse=true;
            }
            else{
                lighthouse=false;
            }
        }
    }
    if(currentScenerio==1){
         if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        moving = !moving; // Toggle movement
        if (moving) {
            glutTimerFunc(20, updateTrain, 0);
        }
    }
    }
    if(currentScenerio==2){
         if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        carRunning = true;
        updateCarPosition(0); // Start moving the car
    } else  {
        carRunning = false; // Stop the car
    }
    }
    if(currentScenerio==3){
        if (state == GLUT_DOWN&&button == GLUT_LEFT_BUTTON) { // When the mouse button is pressed
            active = !active;
             if (active && !timerRunning) {  // Start the timer only if not running
            timerRunning = true;
            glutTimerFunc(20, update1, 0);
        }

    }

    glutPostRedisplay();
    }
}

int main(int argc, char** argv) {

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1500, 1000);
    glutInitWindowPosition(200, 0);
    glutCreateWindow("Maritime World Journey");
    glutDisplayFunc(display);
    initStars();
    if (currentScenerio == 0) {
        glutTimerFunc(20, update, 0); // Timer function for scenario 0
    } else if (currentScenerio == 1) {
        glutTimerFunc(0, timer, 0); // Timer function for scenario 1
    }
    else if(currentScenerio == 2){
        glutTimerFunc(0, timer2, 0);
    }
    else if(currentScenerio == 3){
        glutTimerFunc(25, update3, 0);

    }
    glutKeyboardFunc(handleKeyboard);
    glutMouseFunc(mouse);

    //Cout
    cout<<"To change scenerio - press 1/2/3/4"<<endl;
    cout<<"Start ship - press s"<<endl;
    cout<<"Night - press n"<<endl;
    cout<<"Day - press d"<<endl;
    cout<<"Rain on scenario 2 - Press c"<<endl;
    cout<<"To Reset - Press r"<<endl;
    glutMainLoop();
    return 0;
}




